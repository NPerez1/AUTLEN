#ifndef MINIMIZA_H
#define MINIMIZA_H

#include "afnd.h"

AFND * AFNDMinimiza(AFND * afnd);

#endif