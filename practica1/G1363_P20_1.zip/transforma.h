#ifndef TRANS_H
#define TRANS_H

#include "afnd.h"

AFND * AFNDTransforma(AFND * afnd);

#endif