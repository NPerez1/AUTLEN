#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef _afnd_ofus_foo
#define _afnd_ofus_foo
typedef void (*_afnd_ofus_bar)(void *);
typedef void(*(*_afnd_ofus_baz)(const void *));
typedef int (*_afnd_ofus_fobar)(FILE *, const void *);
typedef int (*_afnd_ofus_foobar)(const void *, const void *);
#endif
#ifndef _afnd_ofus_fobaz
#define _afnd_ofus_fobaz
int _afnd_ofus_foobaz(FILE *fd, const void *_afnd_ofus_quux);
void *_afnd_ofus_fred(const void *_afnd_ofus_quux);
void _afnd_ofus_dog(void *_afnd_ofus_quux);
int _afnd_ofus_cat(const void *_afnd_ofus_fish, const void *_afnd_ofus_gasp);
#endif
#ifndef _afnd_ofus_bad
#define _afnd_ofus_bad
typedef enum
{
    _afnd_ofus_bug = 0,
    _afnd_ofus_silly = 1
} _afnd_ofus_buggy;
typedef enum
{
    _afnd_ofus_mum = 0,
    _afnd_ofus_dad = 1
} _afnd_ofus_disk;
#endif
#ifndef _afnd_ofus_empty
#define _afnd_ofus_empty
#define INICIAL 0
#define FINAL 1
#define INICIAL_Y_FINAL 2
#define NORMAL 3
typedef struct _afnd_ofus_full _afnd_ofus_fast;
_afnd_ofus_fast *
_afnd_ofus_small(char *nombre, int tipo);
void _afnd_ofus_big(_afnd_ofus_fast *
                        _afnd_ofus_ok);
void _afnd_ofus_hello(FILE *fd, _afnd_ofus_fast *_afnd_ofus_ok);
int _afnd_ofus_bye(_afnd_ofus_fast *_afnd_ofus_ok, char *nombre);
char *
_afnd_ofus_magic(_afnd_ofus_fast *_afnd_ofus_ok);
int _afnd_ofus_obscure(
    _afnd_ofus_fast *_afnd_ofus_ok);
_afnd_ofus_fast *_afnd_ofus_speed(
    _afnd_ofus_fast *_afnd_ofus_ok);
int _afnd_ofus_index(_afnd_ofus_fast *
                         _afnd_ofus_bill,
                     _afnd_ofus_fast *_afnd_ofus_joe);
void _afnd_ofus_emacs(FILE *fd,
                      _afnd_ofus_fast *_afnd_ofus_ok);
#endif
#ifndef _afnd_ofus_vi
#define _afnd_ofus_vi
typedef struct _afnd_ofus_rms _afnd_ofus_fbi;
_afnd_ofus_fbi *_afnd_ofus_cia(
    char *nombre, int _afnd_ofus_nasa);
void _afnd_ofus_err(_afnd_ofus_fbi *
                        _afnd_ofus_google);
_afnd_ofus_fbi *_afnd_ofus_yahoo(_afnd_ofus_fbi *
                                     _afnd_ofus_google,
                                 char *simbolo);
void _afnd_ofus_trick(FILE *fd, _afnd_ofus_fbi *
                                    _afnd_ofus_hint);
char *_afnd_ofus_black(_afnd_ofus_fbi *_afnd_ofus_hint, int i);
int _afnd_ofus_red(_afnd_ofus_fbi *_afnd_ofus_hint, char *simbolo);
int _afnd_ofus_green(_afnd_ofus_fbi *_afnd_ofus_hint);
_afnd_ofus_fbi *
_afnd_ofus_yellow(_afnd_ofus_fbi *_afnd_ofus_blue, _afnd_ofus_fbi *
                                                       _afnd_ofus_magenta);
#endif
#ifndef _afnd_ofus_cyan
#define _afnd_ofus_cyan
typedef struct _afnd_ofus_white _afnd_ofus_clinton;
_afnd_ofus_clinton *
_afnd_ofus_bush();
void _afnd_ofus_jfk(_afnd_ofus_clinton *_afnd_ofus_sex);
void _afnd_ofus_bar_foo(FILE *fd, _afnd_ofus_clinton *_afnd_ofus_sex);
_afnd_ofus_clinton *_afnd_ofus_bar_bar(_afnd_ofus_clinton *_afnd_ofus_sex, char *
                                                                               letra);
char *_afnd_ofus_bar_baz(_afnd_ofus_clinton *_afnd_ofus_sex);
int _afnd_ofus_bar_fobar(_afnd_ofus_clinton *_afnd_ofus_sex);
#endif
#ifndef _afnd_ofus_bar_foobar
#define _afnd_ofus_bar_foobar
typedef struct _afnd_ofus_bar_fobaz _afnd_ofus_bar_foobaz;
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_quux(char *nombre, int _afnd_ofus_bar_fred);
void _afnd_ofus_bar_dog(FILE *fd, _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat);
void _afnd_ofus_bar_fish(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat);
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_gasp(_afnd_ofus_bar_foobaz *
                                               _afnd_ofus_bar_bad);
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_bug(
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat, int i, int j);
int _afnd_ofus_bar_silly(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat);
int _afnd_ofus_bar_buggy(
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat);
_afnd_ofus_bar_foobaz *
_afnd_ofus_bar_mum(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat);
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_dad(_afnd_ofus_bar_foobaz *
                                              _afnd_ofus_bar_cat);
int _afnd_ofus_bar_disk(_afnd_ofus_bar_foobaz *
                            _afnd_ofus_bar_cat,
                        int i, int j);
int _afnd_ofus_bar_empty(_afnd_ofus_bar_foobaz
                             *_afnd_ofus_bar_cat,
                         int i, int j);
#endif
#ifndef _afnd_ofus_bar_full
#define _afnd_ofus_bar_full
typedef struct _afnd_ofus_bar_fast _afnd_ofus_bar_small;
_afnd_ofus_bar_small *
_afnd_ofus_bar_big();
void _afnd_ofus_bar_ok(_afnd_ofus_bar_small *
                           _afnd_ofus_bar_hello,
                       _afnd_ofus_bar _afnd_ofus_bar_bye);
_afnd_ofus_bar_small *
_afnd_ofus_bar_magic(const _afnd_ofus_bar_small *_afnd_ofus_bar_hello);
_afnd_ofus_bar_small *_afnd_ofus_bar_obscure(_afnd_ofus_bar_small *
                                                 _afnd_ofus_bar_hello,
                                             const _afnd_ofus_bar_small *_afnd_ofus_bar_speed);
void *
_afnd_ofus_bar_index(const _afnd_ofus_bar_small *_afnd_ofus_bar_hello);
_afnd_ofus_bar_small *_afnd_ofus_bar_bill(_afnd_ofus_bar_small *
                                              _afnd_ofus_bar_hello,
                                          const void *_afnd_ofus_bar_joe);
int _afnd_ofus_bar_emacs(
    FILE *fd, const _afnd_ofus_bar_small *_afnd_ofus_bar_hello, _afnd_ofus_fobar _afnd_ofus_bar_vi);
#endif
#ifndef _afnd_ofus_bar_rms
#define _afnd_ofus_bar_rms
typedef struct _afnd_ofus_bar_fbi _afnd_ofus_bar_cia;
_afnd_ofus_bar_cia *
_afnd_ofus_bar_nasa(_afnd_ofus_bar _afnd_ofus_bar_err, _afnd_ofus_baz _afnd_ofus_bar_google, _afnd_ofus_fobar _afnd_ofus_bar_yahoo, _afnd_ofus_foobar _afnd_ofus_bar_trick);
void _afnd_ofus_bar_hint(_afnd_ofus_bar_cia *
                             _afnd_ofus_bar_black);
_afnd_ofus_bar_cia *_afnd_ofus_bar_red(_afnd_ofus_bar_cia
                                           *_afnd_ofus_bar_black,
                                       const void *_afnd_ofus_bar_green);
_afnd_ofus_bar_cia *
_afnd_ofus_bar_yellow(_afnd_ofus_bar_cia *_afnd_ofus_bar_black, const void *
                                                                    _afnd_ofus_bar_green);
_afnd_ofus_bar_cia *_afnd_ofus_bar_blue(
    _afnd_ofus_bar_cia *_afnd_ofus_bar_black, const void *_afnd_ofus_bar_magenta);
void *_afnd_ofus_bar_cyan(_afnd_ofus_bar_cia *_afnd_ofus_bar_black);
void *
_afnd_ofus_bar_white(_afnd_ofus_bar_cia *_afnd_ofus_bar_black);
_afnd_ofus_disk
_afnd_ofus_bar_clinton(const _afnd_ofus_bar_cia *_afnd_ofus_bar_black);
const void *_afnd_ofus_bar_bush(const _afnd_ofus_bar_cia *_afnd_ofus_bar_black, int i);
int _afnd_ofus_bar_jfk(const _afnd_ofus_bar_cia *_afnd_ofus_bar_black);
int _afnd_ofus_bar_sex(FILE *fd, const _afnd_ofus_bar_cia *_afnd_ofus_bar_black);
int _afnd_ofus_baz_foo(const _afnd_ofus_bar_cia *_afnd_ofus_bar_black, void *
                                                                           _afnd_ofus_baz_bar);
#endif
#ifndef AFND_H
#define AFND_H
#define INICIAL 0
#define FINAL 1
#define INICIAL_Y_FINAL 2
#define NORMAL 3
typedef struct _AFND AFND;
AFND *AFNDNuevo(char *nombre, int num_estados, int num_simbolos);
void AFNDElimina(AFND *p_afnd);
void AFNDImprime(FILE *fd, AFND *
                               p_afnd);
int AFNDIndiceDeSimbolo(AFND *p_afnd, char *nombre);
int AFNDIndiceDeEstado(AFND *p_afnd, char *nombre);
char *AFNDNombreEstadoEn(AFND *
                             p_afnd,
                         int pos);
char *AFNDSimboloEn(AFND *p_afnd, int pos);
AFND *
AFNDInsertaSimbolo(AFND *p_afnd, char *simbolo);
AFND *AFNDInsertaEstado(AFND *
                            p_afnd,
                        char *nombre, int tipo);
AFND *AFNDInsertaTransicion(AFND *p_afnd, char *nombre_estado_i, char *nombre_simbolo_entrada, char *nombre_estado_f);
AFND *
AFNDInsertaLTransicion(AFND *p_afnd, char *nombre_estado_i, char *nombre_estado_f);
AFND *AFNDInsertaLetra(AFND *p_afnd, char *letra);
void AFNDImprimeConjuntoEstadosActual(FILE *fd, AFND *p_afnd);
void AFNDImprimeCadenaActual(FILE *fd, AFND *p_afnd);
void AFNDTransita(AFND *p_afnd);
void AFNDProcesaEntrada(FILE *fd, AFND *p_afnd);
int AFNDIndiceEstadoInicial(AFND *
                                p_afnd);
AFND *AFNDInicializaEstado(AFND *p_afnd);
AFND *AFNDInicializaCadenaActual(AFND *p_afnd);
AFND *AFNDCierraLTransicion(AFND *p_afnd);
int AFNDLTransicionIJ(
    AFND *p_afnd, int i, int j);
int AFNDTransicionIndicesEstadoiSimboloEstadof(AFND *
                                                   p_afnd,
                                               int i_e1, int i_s, int i_e2);
int AFNDCierreLTransicionIJ(AFND *p_afnd, int i, int j);
int AFNDIndicePrimerEstadoFinal(AFND *p_afnd);
void AFNDADot(AFND *
                  p_afnd);
int AFNDNumSimbolos(AFND *p_afnd);
int AFNDNumEstados(AFND *p_afnd);
int AFNDTipoEstadoEn(AFND *p_afnd, int pos);
#endif
int _afnd_ofus_foobaz(FILE *fd, const void *_afnd_ofus_quux)
{
    return fprintf(fd,
                   "%s", (char *)_afnd_ofus_quux);
}
void *_afnd_ofus_fred(const void *_afnd_ofus_quux)
{
    char *_afnd_ofus_baz_baz;
    _afnd_ofus_baz_baz = (char *)malloc(strlen((char *)
                                                   _afnd_ofus_quux) +
                                        1);
    strcpy(_afnd_ofus_baz_baz, (char *)_afnd_ofus_quux);
    return (
        void *)_afnd_ofus_baz_baz;
}
void _afnd_ofus_dog(void *_afnd_ofus_quux)
{
    {
        if (!(
                _afnd_ofus_quux != NULL))
            goto _afnd_ofus_baz_fobar;
        {
            free(_afnd_ofus_quux);
        }
    _afnd_ofus_baz_fobar:;
    }
}
int _afnd_ofus_cat(const void *_afnd_ofus_fish, const void *_afnd_ofus_gasp) { return strcmp((char *)_afnd_ofus_fish, (char *)
                                                                                                                          _afnd_ofus_gasp); }
struct _afnd_ofus_bar_fast
{
    void *_afnd_ofus_bar_joe;
    struct
        _afnd_ofus_bar_fast *_afnd_ofus_bar_speed;
};
_afnd_ofus_bar_small *
_afnd_ofus_bar_big()
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_baz;
    _afnd_ofus_baz_baz = (_afnd_ofus_bar_small *)malloc(sizeof(_afnd_ofus_bar_small));
    _afnd_ofus_baz_baz->_afnd_ofus_bar_joe = NULL;
    _afnd_ofus_baz_baz->_afnd_ofus_bar_speed = NULL;
    return _afnd_ofus_baz_baz;
}
void _afnd_ofus_bar_ok(
    _afnd_ofus_bar_small *_afnd_ofus_bar_hello, _afnd_ofus_bar _afnd_ofus_bar_bye)
{
    {
        if (!(_afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_foobar;
        {
            _afnd_ofus_bar_bye(_afnd_ofus_bar_hello->_afnd_ofus_bar_joe);
            free(
                _afnd_ofus_bar_hello);
        }
    _afnd_ofus_baz_foobar:;
    }
}
_afnd_ofus_bar_small *
_afnd_ofus_bar_magic(const _afnd_ofus_bar_small *_afnd_ofus_bar_hello)
{
    {
        if (!(
                _afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_fobaz;
        {
            return _afnd_ofus_bar_hello->_afnd_ofus_bar_speed;
        }
    _afnd_ofus_baz_fobaz:;
    }
    return NULL;
}
_afnd_ofus_bar_small *_afnd_ofus_bar_obscure(_afnd_ofus_bar_small *
                                                 _afnd_ofus_bar_hello,
                                             const _afnd_ofus_bar_small *_afnd_ofus_bar_speed)
{
    {
        if (!(
                _afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_foobaz;
        {
            _afnd_ofus_bar_hello->_afnd_ofus_bar_speed = (_afnd_ofus_bar_small *)_afnd_ofus_bar_speed;
            return _afnd_ofus_bar_hello;
        }
    _afnd_ofus_baz_foobaz:;
    }
    return _afnd_ofus_bar_hello;
}
void *_afnd_ofus_bar_index(const _afnd_ofus_bar_small *_afnd_ofus_bar_hello)
{
    {
        if (!(_afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_quux;
        {
            return _afnd_ofus_bar_hello->_afnd_ofus_bar_joe;
        }
    _afnd_ofus_baz_quux:;
    }
    return NULL;
}
_afnd_ofus_bar_small *_afnd_ofus_bar_bill(_afnd_ofus_bar_small *
                                              _afnd_ofus_bar_hello,
                                          const void *_afnd_ofus_bar_joe)
{
    {
        if (!(_afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_fred;
        _afnd_ofus_bar_hello->_afnd_ofus_bar_joe = (void *)_afnd_ofus_bar_joe;
    _afnd_ofus_baz_fred:;
    }
    return _afnd_ofus_bar_hello;
}
int _afnd_ofus_bar_emacs(FILE *fd, const _afnd_ofus_bar_small *_afnd_ofus_bar_hello, _afnd_ofus_fobar _afnd_ofus_bar_vi)
{
    {
        if (!(
                _afnd_ofus_bar_hello != NULL))
            goto _afnd_ofus_baz_dog;
        {
            return _afnd_ofus_bar_vi(
                fd, _afnd_ofus_bar_hello->_afnd_ofus_bar_joe);
        }
        goto _afnd_ofus_baz_cat;
    _afnd_ofus_baz_dog:;
        return 0;
    _afnd_ofus_baz_cat:;
    }
}
struct _afnd_ofus_bar_fbi
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_fish;
    _afnd_ofus_bar _afnd_ofus_baz_gasp;
    _afnd_ofus_baz _afnd_ofus_baz_bad;
    _afnd_ofus_fobar _afnd_ofus_baz_bug;
    _afnd_ofus_foobar _afnd_ofus_baz_silly;
};
_afnd_ofus_bar_cia *
_afnd_ofus_bar_nasa(_afnd_ofus_bar _afnd_ofus_bar_err, _afnd_ofus_baz _afnd_ofus_bar_google, _afnd_ofus_fobar _afnd_ofus_bar_yahoo, _afnd_ofus_foobar _afnd_ofus_bar_trick)
{
    _afnd_ofus_bar_cia *_afnd_ofus_baz_buggy;
    {
        if (!((
                  _afnd_ofus_baz_buggy = (_afnd_ofus_bar_cia *)malloc(sizeof(_afnd_ofus_bar_cia))) == NULL))
            goto _afnd_ofus_baz_mum;
        return NULL;
    _afnd_ofus_baz_mum:;
    }
    _afnd_ofus_baz_buggy->_afnd_ofus_baz_fish = NULL;
    _afnd_ofus_baz_buggy->_afnd_ofus_baz_gasp = _afnd_ofus_bar_err;
    _afnd_ofus_baz_buggy->_afnd_ofus_baz_bad = _afnd_ofus_bar_google;
    _afnd_ofus_baz_buggy->_afnd_ofus_baz_bug = _afnd_ofus_bar_yahoo;
    _afnd_ofus_baz_buggy->_afnd_ofus_baz_silly = _afnd_ofus_bar_trick;
    return _afnd_ofus_baz_buggy;
}
void _afnd_ofus_bar_hint(_afnd_ofus_bar_cia *_afnd_ofus_bar_black)
{
    void *
        _afnd_ofus_baz_dad;
    {
        if (!(!_afnd_ofus_bar_black))
            goto _afnd_ofus_baz_disk;
        return;
    _afnd_ofus_baz_disk:;
    }
    {
    _afnd_ofus_baz_empty:
        if (!(!_afnd_ofus_bar_clinton(_afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_full;
        {
            _afnd_ofus_baz_dad = _afnd_ofus_bar_cyan(_afnd_ofus_bar_black);
            _afnd_ofus_bar_black->_afnd_ofus_baz_gasp(_afnd_ofus_baz_dad);
        }
        goto _afnd_ofus_baz_empty;
    _afnd_ofus_baz_full:;
    }
    free(_afnd_ofus_bar_black);
}
_afnd_ofus_bar_cia *_afnd_ofus_bar_red(_afnd_ofus_bar_cia *_afnd_ofus_bar_black,
                                       const void *_afnd_ofus_bar_magenta)
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_fish;
    {
        if (!(!_afnd_ofus_bar_black || !_afnd_ofus_bar_magenta))
            goto _afnd_ofus_baz_fast;
        return NULL;
    _afnd_ofus_baz_fast:;
    }
    _afnd_ofus_baz_fish = _afnd_ofus_bar_big();
    _afnd_ofus_bar_bill(_afnd_ofus_baz_fish, _afnd_ofus_bar_black->_afnd_ofus_baz_bad(_afnd_ofus_bar_magenta));
    _afnd_ofus_bar_obscure(
        _afnd_ofus_baz_fish, _afnd_ofus_bar_black->_afnd_ofus_baz_fish);
    _afnd_ofus_bar_black->_afnd_ofus_baz_fish = _afnd_ofus_baz_fish;
    return _afnd_ofus_bar_black;
}
_afnd_ofus_bar_cia *_afnd_ofus_bar_yellow(
    _afnd_ofus_bar_cia *_afnd_ofus_bar_black, const void *_afnd_ofus_bar_magenta)
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_fish, *_afnd_ofus_baz_small;
    {
        if (!(!_afnd_ofus_bar_black || !_afnd_ofus_bar_magenta))
            goto _afnd_ofus_baz_big;
        return NULL;
    _afnd_ofus_baz_big:;
    }
    _afnd_ofus_baz_fish = _afnd_ofus_bar_big();
    _afnd_ofus_bar_bill(_afnd_ofus_baz_fish, _afnd_ofus_bar_black->_afnd_ofus_baz_bad(_afnd_ofus_bar_magenta));
    {
        if (!(_afnd_ofus_bar_clinton(
                _afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_ok;
        {
            _afnd_ofus_bar_black->_afnd_ofus_baz_fish = _afnd_ofus_baz_fish;
            return _afnd_ofus_bar_black;
        }
    _afnd_ofus_baz_ok:;
    }
    {
        _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    _afnd_ofus_baz_hello:
        if (!(_afnd_ofus_bar_magic(
                  _afnd_ofus_baz_small) != NULL))
            goto _afnd_ofus_baz_bye;
        goto _afnd_ofus_baz_magic;
    _afnd_ofus_baz_obscure:
        _afnd_ofus_baz_small = _afnd_ofus_bar_magic(
            _afnd_ofus_baz_small);
        goto _afnd_ofus_baz_hello;
    _afnd_ofus_baz_magic:;
        goto _afnd_ofus_baz_obscure;
    _afnd_ofus_baz_bye:;
    }
    _afnd_ofus_bar_obscure(
        _afnd_ofus_baz_small, _afnd_ofus_baz_fish);
    return _afnd_ofus_bar_black;
}
_afnd_ofus_bar_cia *_afnd_ofus_bar_blue(_afnd_ofus_bar_cia *_afnd_ofus_bar_black, const void *_afnd_ofus_bar_magenta)
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_fish, *_afnd_ofus_baz_small;
    {
        if (!(!_afnd_ofus_bar_black || !_afnd_ofus_bar_magenta))
            goto _afnd_ofus_baz_speed;
        return NULL;
    _afnd_ofus_baz_speed:;
    }
    _afnd_ofus_baz_fish = _afnd_ofus_bar_big();
    _afnd_ofus_bar_bill(
        _afnd_ofus_baz_fish, _afnd_ofus_bar_black->_afnd_ofus_baz_bad(
                                 _afnd_ofus_bar_magenta));
    {
        if (!(_afnd_ofus_bar_clinton(_afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_index;
        {
            _afnd_ofus_bar_black->_afnd_ofus_baz_fish =
                _afnd_ofus_baz_fish;
            return _afnd_ofus_bar_black;
        }
    _afnd_ofus_baz_index:;
    }
    _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    {
    _afnd_ofus_baz_bill:
        if (!((_afnd_ofus_bar_magic(_afnd_ofus_baz_small) != NULL) && (_afnd_ofus_bar_black->_afnd_ofus_baz_silly(_afnd_ofus_bar_index(
                                                                                                                      _afnd_ofus_bar_magic(_afnd_ofus_baz_small)),
                                                                                                                  _afnd_ofus_bar_magenta) <= 0)))
            goto _afnd_ofus_baz_joe;
        {
            _afnd_ofus_baz_small = _afnd_ofus_bar_magic(
                _afnd_ofus_baz_small);
        }
        goto _afnd_ofus_baz_bill;
    _afnd_ofus_baz_joe:;
    }
    {
        if (!(
                _afnd_ofus_baz_small != _afnd_ofus_bar_black->_afnd_ofus_baz_fish))
            goto _afnd_ofus_baz_emacs;
        {
            _afnd_ofus_bar_obscure(_afnd_ofus_baz_fish,
                                   _afnd_ofus_bar_magic(_afnd_ofus_baz_small));
            _afnd_ofus_bar_obscure(
                _afnd_ofus_baz_small, _afnd_ofus_baz_fish);
        }
        goto _afnd_ofus_baz_vi;
    _afnd_ofus_baz_emacs:;
        {
            {
                if (!(_afnd_ofus_bar_black->_afnd_ofus_baz_silly(
                          _afnd_ofus_bar_index(_afnd_ofus_baz_small), _afnd_ofus_bar_magenta) <= 0))
                    goto _afnd_ofus_baz_rms;
                {
                    _afnd_ofus_bar_obscure(_afnd_ofus_baz_fish,
                                           _afnd_ofus_bar_magic(_afnd_ofus_baz_small));
                    _afnd_ofus_bar_obscure(
                        _afnd_ofus_baz_small, _afnd_ofus_baz_fish);
                }
                goto _afnd_ofus_baz_fbi;
            _afnd_ofus_baz_rms:;
                {
                    _afnd_ofus_bar_obscure(_afnd_ofus_baz_fish,
                                           _afnd_ofus_bar_black->_afnd_ofus_baz_fish);
                    _afnd_ofus_bar_black->_afnd_ofus_baz_fish = _afnd_ofus_baz_fish;
                }
            _afnd_ofus_baz_fbi:;
            }
        }
    _afnd_ofus_baz_vi:;
    }
    return _afnd_ofus_bar_black;
}
void *_afnd_ofus_bar_cyan(
    _afnd_ofus_bar_cia *_afnd_ofus_bar_black)
{
    _afnd_ofus_bar_small *
        _afnd_ofus_baz_small;
    void *_afnd_ofus_bar_magenta;
    {
        if (!(!_afnd_ofus_bar_black ||
              _afnd_ofus_bar_clinton(_afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_cia;
        return NULL;
    _afnd_ofus_baz_cia:;
    }
    _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    _afnd_ofus_bar_magenta = _afnd_ofus_bar_black->_afnd_ofus_baz_bad(_afnd_ofus_bar_index(_afnd_ofus_baz_small));
    _afnd_ofus_bar_black->_afnd_ofus_baz_fish = _afnd_ofus_bar_magic(
        _afnd_ofus_baz_small);
    _afnd_ofus_bar_ok(_afnd_ofus_baz_small,
                      _afnd_ofus_bar_black->_afnd_ofus_baz_gasp);
    return _afnd_ofus_bar_magenta;
}
void
    *
    _afnd_ofus_bar_white(_afnd_ofus_bar_cia *_afnd_ofus_bar_black)
{
    int i;
    _afnd_ofus_bar_small *_afnd_ofus_baz_nasa, *_afnd_ofus_baz_small;
    void *
        _afnd_ofus_bar_magenta;
    {
        if (!(!_afnd_ofus_bar_black || _afnd_ofus_bar_clinton(
                                           _afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_err;
        return NULL;
    _afnd_ofus_baz_err:;
    }
    _afnd_ofus_baz_nasa = NULL;
    _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    i = 0;
    {
    _afnd_ofus_baz_google:
        if (!(_afnd_ofus_bar_magic(
                  _afnd_ofus_baz_small) != NULL))
            goto _afnd_ofus_baz_yahoo;
        {
            _afnd_ofus_baz_nasa =
                _afnd_ofus_baz_small;
            _afnd_ofus_baz_small = _afnd_ofus_bar_magic(
                _afnd_ofus_baz_small);
            i++;
        }
        goto _afnd_ofus_baz_google;
    _afnd_ofus_baz_yahoo:;
    }
    _afnd_ofus_bar_magenta = _afnd_ofus_bar_black->_afnd_ofus_baz_bad(
        _afnd_ofus_bar_index(_afnd_ofus_baz_small));
    {
        if (!(_afnd_ofus_baz_nasa != NULL))
            goto _afnd_ofus_baz_trick;
        _afnd_ofus_bar_obscure(_afnd_ofus_baz_nasa,
                               _afnd_ofus_bar_magic(_afnd_ofus_baz_small));
        goto _afnd_ofus_baz_hint;
    _afnd_ofus_baz_trick:;
        _afnd_ofus_bar_black->_afnd_ofus_baz_fish = NULL;
    _afnd_ofus_baz_hint:;
    }
    _afnd_ofus_bar_ok(_afnd_ofus_baz_small,
                      _afnd_ofus_bar_black->_afnd_ofus_baz_gasp);
    return _afnd_ofus_bar_magenta;
}
_afnd_ofus_disk _afnd_ofus_bar_clinton(const _afnd_ofus_bar_cia *
                                           _afnd_ofus_bar_black)
{
    {
        if (!(_afnd_ofus_bar_black->_afnd_ofus_baz_fish == NULL))
            goto _afnd_ofus_baz_black;
        return _afnd_ofus_dad;
    _afnd_ofus_baz_black:;
    }
    return _afnd_ofus_mum;
}
int _afnd_ofus_bar_jfk(const _afnd_ofus_bar_cia *
                           _afnd_ofus_bar_black)
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_small =
        _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    int i = 0;
    {
    _afnd_ofus_baz_red:
        if (!(
                _afnd_ofus_baz_small != NULL))
            goto _afnd_ofus_baz_green;
        {
            _afnd_ofus_baz_small =
                _afnd_ofus_bar_magic(_afnd_ofus_baz_small);
            i++;
        }
        goto _afnd_ofus_baz_red;
    _afnd_ofus_baz_green:;
    }
    return i;
}
int _afnd_ofus_bar_sex(FILE *fd, const _afnd_ofus_bar_cia *_afnd_ofus_bar_black)
{
    _afnd_ofus_bar_small *
        _afnd_ofus_baz_small;
    int _afnd_ofus_baz_yellow = 0;
    {
        if (!(!_afnd_ofus_bar_black ||
              _afnd_ofus_bar_clinton(_afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_blue;
        return 0;
    _afnd_ofus_baz_blue:;
    }
    _afnd_ofus_baz_yellow += fprintf(fd,
                                     "Lista con %hu elementos: \n", _afnd_ofus_bar_jfk(_afnd_ofus_bar_black));
    _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    {
    _afnd_ofus_baz_magenta:
        if (!(_afnd_ofus_baz_small != NULL))
            goto _afnd_ofus_baz_cyan;
        {
            _afnd_ofus_baz_yellow += _afnd_ofus_bar_emacs(fd,
                                                          _afnd_ofus_baz_small, _afnd_ofus_bar_black->_afnd_ofus_baz_bug);
            _afnd_ofus_baz_yellow += fprintf(fd, "\n");
            _afnd_ofus_baz_small =
                _afnd_ofus_bar_magic(_afnd_ofus_baz_small);
        }
        goto _afnd_ofus_baz_magenta;
    _afnd_ofus_baz_cyan:;
    }
    return _afnd_ofus_baz_yellow;
}
int _afnd_ofus_baz_foo(
    const _afnd_ofus_bar_cia *_afnd_ofus_bar_black, void *_afnd_ofus_bar_magenta)
{
    _afnd_ofus_bar_small *_afnd_ofus_baz_small;
    {
        if (!(!_afnd_ofus_bar_black || !_afnd_ofus_bar_magenta))
            goto _afnd_ofus_baz_white;
        return 0;
    _afnd_ofus_baz_white:;
    }
    {
        if (!(_afnd_ofus_bar_clinton(_afnd_ofus_bar_black)))
            goto _afnd_ofus_baz_clinton;
        {
            return 0;
        }
    _afnd_ofus_baz_clinton:;
    }
    _afnd_ofus_baz_small = _afnd_ofus_bar_black->_afnd_ofus_baz_fish;
    {
    _afnd_ofus_baz_bush:
        if (!((_afnd_ofus_bar_magic(_afnd_ofus_baz_small) != NULL) && (_afnd_ofus_bar_black->_afnd_ofus_baz_silly(_afnd_ofus_bar_index(
                                                                                                                      _afnd_ofus_bar_magic(_afnd_ofus_baz_small)),
                                                                                                                  _afnd_ofus_bar_magenta) != 0)))
            goto _afnd_ofus_baz_jfk;
        {
            fprintf(stdout, "times\n");
            _afnd_ofus_baz_small =
                _afnd_ofus_bar_magic(_afnd_ofus_baz_small);
        }
        goto _afnd_ofus_baz_bush;
    _afnd_ofus_baz_jfk:;
    }
    {
        if (!(_afnd_ofus_bar_magic(_afnd_ofus_baz_small) == NULL))
            goto _afnd_ofus_baz_sex;
        {
            return 0;
        }
        goto _afnd_ofus_fobar_foo;
    _afnd_ofus_baz_sex:;
        return 1;
    _afnd_ofus_fobar_foo:;
    }
}
struct _afnd_ofus_rms
{
    char *nombre;
    int _afnd_ofus_nasa;
    char **_afnd_ofus_fobar_bar;
};
_afnd_ofus_fbi *
_afnd_ofus_cia(char *nombre, int _afnd_ofus_nasa)
{
    _afnd_ofus_fbi *
        _afnd_ofus_google;
    int i;
    _afnd_ofus_google = (_afnd_ofus_fbi *)malloc(sizeof(
        _afnd_ofus_fbi));
    _afnd_ofus_google->nombre = (char *)malloc(strlen(nombre) + 1);
    strcpy(_afnd_ofus_google->nombre, nombre);
    _afnd_ofus_google->_afnd_ofus_nasa =
        _afnd_ofus_nasa;
    _afnd_ofus_google->_afnd_ofus_fobar_bar = (char **)malloc(sizeof(
                                                                  char *) *
                                                              _afnd_ofus_nasa);
    {
        i = 0;
    _afnd_ofus_fobar_baz:
        if (!(i < _afnd_ofus_nasa))
            goto _afnd_ofus_fobar_fobar;
        goto _afnd_ofus_fobar_foobar;
    _afnd_ofus_fobar_fobaz:
        i++;
        goto _afnd_ofus_fobar_baz;
    _afnd_ofus_fobar_foobar:
    {
        _afnd_ofus_google->_afnd_ofus_fobar_bar[i] = NULL;
    }
        goto _afnd_ofus_fobar_fobaz;
    _afnd_ofus_fobar_fobar:;
    }
    return _afnd_ofus_google;
}
void _afnd_ofus_err(
    _afnd_ofus_fbi *_afnd_ofus_google)
{
    int i;
    {
        if (!(_afnd_ofus_google == NULL))
            goto _afnd_ofus_fobar_foobaz;
        return;
    _afnd_ofus_fobar_foobaz:;
    }
    {
        if (!(
                _afnd_ofus_google->nombre != NULL))
            goto _afnd_ofus_fobar_quux;
        {
            free(
                _afnd_ofus_google->nombre);
            _afnd_ofus_google->nombre = NULL;
        }
    _afnd_ofus_fobar_quux:;
    }
    {
        i = 0;
    _afnd_ofus_fobar_fred:
        if (!(i < _afnd_ofus_google->_afnd_ofus_nasa))
            goto _afnd_ofus_fobar_dog;
        goto _afnd_ofus_fobar_cat;
    _afnd_ofus_fobar_fish:
        i++;
        goto _afnd_ofus_fobar_fred;
    _afnd_ofus_fobar_cat:
    {
        {
            if (!(_afnd_ofus_google->_afnd_ofus_fobar_bar[i] != NULL))
                goto _afnd_ofus_fobar_gasp;
            {
                free(_afnd_ofus_google->_afnd_ofus_fobar_bar[i]);
            }
        _afnd_ofus_fobar_gasp:;
        }
    }
        goto _afnd_ofus_fobar_fish;
    _afnd_ofus_fobar_dog:;
    }
    {
        if (!(_afnd_ofus_google->_afnd_ofus_fobar_bar != NULL))
            goto _afnd_ofus_fobar_bad;
        free(_afnd_ofus_google->_afnd_ofus_fobar_bar);
    _afnd_ofus_fobar_bad:;
    }
    free(
        _afnd_ofus_google);
}
_afnd_ofus_fbi *_afnd_ofus_yahoo(_afnd_ofus_fbi *
                                     _afnd_ofus_google,
                                 char *simbolo)
{
    int i;
    i = 0;
    {
        i = 0;
    _afnd_ofus_fobar_bug:
        if (!(i <
              _afnd_ofus_google->_afnd_ofus_nasa))
            goto _afnd_ofus_fobar_silly;
        goto _afnd_ofus_fobar_buggy;
    _afnd_ofus_fobar_mum:
        i++;
        goto _afnd_ofus_fobar_bug;
    _afnd_ofus_fobar_buggy:
    {
        {
            if (!(_afnd_ofus_google->_afnd_ofus_fobar_bar[i] == NULL))
                goto _afnd_ofus_fobar_dad;
            {
                _afnd_ofus_google->_afnd_ofus_fobar_bar[i] = (char *)malloc(strlen(simbolo) + 1);
                strcpy(_afnd_ofus_google->_afnd_ofus_fobar_bar[i],
                       simbolo);
                goto _afnd_ofus_fobar_silly;
            }
        _afnd_ofus_fobar_dad:;
        }
    }
        goto _afnd_ofus_fobar_mum;
    _afnd_ofus_fobar_silly:;
    }
    return _afnd_ofus_google;
}
void _afnd_ofus_trick(FILE *fd, _afnd_ofus_fbi *_afnd_ofus_hint)
{
    int i;
    {
        if (!(
                _afnd_ofus_hint->nombre != NULL))
            goto _afnd_ofus_fobar_disk;
        fprintf(fd, "%s=",
                _afnd_ofus_hint->nombre);
    _afnd_ofus_fobar_disk:;
    }
    fprintf(fd, "{ ");
    {
        i = 0;
    _afnd_ofus_fobar_empty:
        if (!(i < _afnd_ofus_hint->_afnd_ofus_nasa))
            goto _afnd_ofus_fobar_full;
        goto _afnd_ofus_fobar_fast;
    _afnd_ofus_fobar_small:
        i++;
        goto _afnd_ofus_fobar_empty;
    _afnd_ofus_fobar_fast:
    {
        {
            if (!(_afnd_ofus_hint->_afnd_ofus_fobar_bar[i] == NULL))
                goto _afnd_ofus_fobar_big;
            goto _afnd_ofus_fobar_full;
            goto _afnd_ofus_fobar_ok;
        _afnd_ofus_fobar_big:;
            fprintf(
                fd, "%s ", _afnd_ofus_hint->_afnd_ofus_fobar_bar[i]);
        _afnd_ofus_fobar_ok:;
        }
    }
        goto _afnd_ofus_fobar_small;
    _afnd_ofus_fobar_full:;
    }
    fprintf(fd, "}\n");
}
char *
_afnd_ofus_black(_afnd_ofus_fbi *_afnd_ofus_hint, int i)
{
    {
        if (!(i < _afnd_ofus_hint
                      ->_afnd_ofus_nasa))
            goto _afnd_ofus_fobar_hello;
        return _afnd_ofus_hint->_afnd_ofus_fobar_bar[i];
    _afnd_ofus_fobar_hello:;
    }
    return NULL;
}
int _afnd_ofus_red(_afnd_ofus_fbi *_afnd_ofus_hint, char *simbolo)
{
    int j;
    {
        if (!(
                _afnd_ofus_hint->_afnd_ofus_nasa == 0))
            goto _afnd_ofus_fobar_bye;
        return -1;
    _afnd_ofus_fobar_bye:;
    }
    {
        j = 0;
    _afnd_ofus_fobar_magic:
        if (!(j < _afnd_ofus_hint->_afnd_ofus_nasa))
            goto _afnd_ofus_fobar_obscure;
        goto _afnd_ofus_fobar_speed;
    _afnd_ofus_fobar_index:
        j++;
        goto _afnd_ofus_fobar_magic;
    _afnd_ofus_fobar_speed:
    {
        {
            if (!(strcmp(simbolo, _afnd_ofus_hint->_afnd_ofus_fobar_bar[j]) == 0))
                goto _afnd_ofus_fobar_bill;
            {
                return j;
                goto _afnd_ofus_fobar_obscure;
            }
        _afnd_ofus_fobar_bill:;
        }
    }
        goto _afnd_ofus_fobar_index;
    _afnd_ofus_fobar_obscure:;
    }
    return -1;
}
int _afnd_ofus_green(_afnd_ofus_fbi *_afnd_ofus_hint)
{
    {
        if (!(
                _afnd_ofus_hint == NULL))
            goto _afnd_ofus_fobar_joe;
        return -1;
    _afnd_ofus_fobar_joe
        :;
    }
    return _afnd_ofus_hint->_afnd_ofus_nasa;
}
int _afnd_ofus_fobar_emacs(
    _afnd_ofus_fbi *_afnd_ofus_hint, char *simbolo) { return (_afnd_ofus_red(_afnd_ofus_hint, simbolo) != -1); }
_afnd_ofus_fbi *_afnd_ofus_yellow(_afnd_ofus_fbi
                                      *_afnd_ofus_blue,
                                  _afnd_ofus_fbi *_afnd_ofus_magenta)
{
    char *_afnd_ofus_fobar_vi;
    _afnd_ofus_fbi *_afnd_ofus_baz_baz;
    int _afnd_ofus_fobar_rms = 0;
    int i;
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char *) * (strlen(_afnd_ofus_blue->nombre) + strlen(_afnd_ofus_magenta->nombre) + strlen("_U_") + 1));
    _afnd_ofus_fobar_vi = strcpy(_afnd_ofus_fobar_vi, _afnd_ofus_blue->nombre);
    _afnd_ofus_fobar_vi = strcat(_afnd_ofus_fobar_vi, "_U_");
    _afnd_ofus_fobar_vi =
        strcat(_afnd_ofus_fobar_vi, _afnd_ofus_magenta->nombre);
    _afnd_ofus_fobar_rms =
        _afnd_ofus_green(_afnd_ofus_blue);
    {
        i = 0;
    _afnd_ofus_fobar_fbi:
        if (!(i <
              _afnd_ofus_green(_afnd_ofus_magenta)))
            goto _afnd_ofus_fobar_cia;
        goto _afnd_ofus_fobar_nasa;
    _afnd_ofus_fobar_err:
        i++;
        goto _afnd_ofus_fobar_fbi;
    _afnd_ofus_fobar_nasa:
    {
        {
            if (!(_afnd_ofus_fobar_emacs(_afnd_ofus_blue,
                                         _afnd_ofus_black(_afnd_ofus_magenta, i)) != 1))
                goto _afnd_ofus_fobar_google;
            {
                _afnd_ofus_fobar_rms++;
            }
        _afnd_ofus_fobar_google:;
        }
    }
        goto _afnd_ofus_fobar_err;
    _afnd_ofus_fobar_cia:;
    }
    _afnd_ofus_baz_baz = _afnd_ofus_cia(_afnd_ofus_fobar_vi,
                                        _afnd_ofus_fobar_rms);
    free(_afnd_ofus_fobar_vi);
    {
        i = 0;
    _afnd_ofus_fobar_yahoo:
        if (!(i < _afnd_ofus_green(_afnd_ofus_blue)))
            goto _afnd_ofus_fobar_trick;
        goto _afnd_ofus_fobar_hint;
    _afnd_ofus_fobar_black:
        i++;
        goto _afnd_ofus_fobar_yahoo;
    _afnd_ofus_fobar_hint:
    {
        _afnd_ofus_yahoo(_afnd_ofus_baz_baz, _afnd_ofus_black(
                                                 _afnd_ofus_blue, i));
    }
        goto _afnd_ofus_fobar_black;
    _afnd_ofus_fobar_trick:;
    }
    {
        i = 0;
    _afnd_ofus_fobar_red:
        if (!(i < _afnd_ofus_green(_afnd_ofus_magenta)))
            goto _afnd_ofus_fobar_green;
        goto _afnd_ofus_fobar_yellow;
    _afnd_ofus_fobar_blue:
        i++;
        goto _afnd_ofus_fobar_red;
    _afnd_ofus_fobar_yellow:
    {
        {
            if (!(
                    _afnd_ofus_fobar_emacs(_afnd_ofus_blue, _afnd_ofus_black(_afnd_ofus_magenta, i)) != 1))
                goto _afnd_ofus_fobar_magenta;
            {
                _afnd_ofus_yahoo(_afnd_ofus_baz_baz,
                                 _afnd_ofus_black(_afnd_ofus_magenta, i));
            }
        _afnd_ofus_fobar_magenta:;
        }
    }
        goto _afnd_ofus_fobar_blue;
    _afnd_ofus_fobar_green:;
    }
    return _afnd_ofus_baz_baz;
}
struct _afnd_ofus_white
{
    char **_afnd_ofus_fobar_cyan;
    int _afnd_ofus_nasa;
};
_afnd_ofus_clinton *_afnd_ofus_bush()
{
    _afnd_ofus_clinton *_afnd_ofus_fobar_white;
    _afnd_ofus_fobar_white = (_afnd_ofus_clinton *)malloc(sizeof(_afnd_ofus_clinton));
    _afnd_ofus_fobar_white->_afnd_ofus_fobar_cyan = NULL;
    _afnd_ofus_fobar_white->_afnd_ofus_nasa = 0;
    return _afnd_ofus_fobar_white;
}
_afnd_ofus_clinton *
_afnd_ofus_bar_bar(_afnd_ofus_clinton *_afnd_ofus_sex, char *letra)
{
    _afnd_ofus_sex->_afnd_ofus_fobar_cyan = (char **)realloc(_afnd_ofus_sex->_afnd_ofus_fobar_cyan, (_afnd_ofus_sex->_afnd_ofus_nasa + 1) * sizeof(char *));
    _afnd_ofus_sex->_afnd_ofus_fobar_cyan[_afnd_ofus_sex->_afnd_ofus_nasa] = (char *)
        malloc((strlen(letra) + 1) * sizeof(char));
    strcpy(_afnd_ofus_sex->_afnd_ofus_fobar_cyan[_afnd_ofus_sex->_afnd_ofus_nasa], letra);
    (_afnd_ofus_sex
         ->_afnd_ofus_nasa)++;
    return _afnd_ofus_sex;
}
char *_afnd_ofus_bar_baz(
    _afnd_ofus_clinton *_afnd_ofus_sex)
{
    int i;
    char *_afnd_ofus_fobar_clinton;
    {
        if (!(
                _afnd_ofus_sex == NULL))
            goto _afnd_ofus_fobar_bush;
        return NULL;
    _afnd_ofus_fobar_bush:;
    }
    {
        if (!(_afnd_ofus_sex->_afnd_ofus_nasa == 0))
            goto _afnd_ofus_fobar_jfk;
        return NULL;
    _afnd_ofus_fobar_jfk:;
    }
    _afnd_ofus_fobar_clinton = _afnd_ofus_sex->_afnd_ofus_fobar_cyan[0];
    {
        i = 1;
    _afnd_ofus_fobar_sex:
        if (!(i < _afnd_ofus_sex->_afnd_ofus_nasa))
            goto _afnd_ofus_foobar_foo;
        goto _afnd_ofus_foobar_bar;
    _afnd_ofus_foobar_baz:
        i++;
        goto _afnd_ofus_fobar_sex;
    _afnd_ofus_foobar_bar:
    {
        _afnd_ofus_sex->_afnd_ofus_fobar_cyan[i - 1] = _afnd_ofus_sex->_afnd_ofus_fobar_cyan[i];
    }
        goto _afnd_ofus_foobar_baz;
    _afnd_ofus_foobar_foo:;
    }
    (_afnd_ofus_sex->_afnd_ofus_nasa)--;
    _afnd_ofus_sex->_afnd_ofus_fobar_cyan = (char **)realloc(_afnd_ofus_sex->_afnd_ofus_fobar_cyan, _afnd_ofus_sex->_afnd_ofus_nasa * sizeof(char *));
    return _afnd_ofus_fobar_clinton;
}
void _afnd_ofus_jfk(_afnd_ofus_clinton *
                        _afnd_ofus_foobar_fobar)
{
    int i;
    {
        if (!(_afnd_ofus_foobar_fobar == NULL))
            goto _afnd_ofus_foobar_foobar;
        return;
    _afnd_ofus_foobar_foobar:;
    }
    {
        if (!(
                _afnd_ofus_foobar_fobar->_afnd_ofus_fobar_cyan != NULL))
            goto _afnd_ofus_foobar_fobaz;
        {
            {
                i = 0;
            _afnd_ofus_foobar_foobaz:
                if (!(i <
                      _afnd_ofus_foobar_fobar->_afnd_ofus_nasa))
                    goto _afnd_ofus_foobar_quux;
                goto _afnd_ofus_foobar_fred;
            _afnd_ofus_foobar_dog:
                i++;
                goto _afnd_ofus_foobar_foobaz;
            _afnd_ofus_foobar_fred:
            {
                free(_afnd_ofus_foobar_fobar->_afnd_ofus_fobar_cyan[i]);
            }
                goto _afnd_ofus_foobar_dog;
            _afnd_ofus_foobar_quux:;
            }
        }
    _afnd_ofus_foobar_fobaz:;
    }
    free(_afnd_ofus_foobar_fobar->_afnd_ofus_fobar_cyan);
    free(_afnd_ofus_foobar_fobar);
}
void _afnd_ofus_bar_foo(FILE *fd,
                        _afnd_ofus_clinton *_afnd_ofus_foobar_fobar)
{
    int i;
    {
        if (!(
                _afnd_ofus_foobar_fobar == NULL))
            goto _afnd_ofus_foobar_cat;
        return;
    _afnd_ofus_foobar_cat:;
    }
    fprintf(fd, "[(%d)", _afnd_ofus_foobar_fobar->_afnd_ofus_nasa);
    {
        i = 0;
    _afnd_ofus_foobar_fish:
        if (!(i < _afnd_ofus_foobar_fobar->_afnd_ofus_nasa))
            goto _afnd_ofus_foobar_gasp;
        goto _afnd_ofus_foobar_bad;
    _afnd_ofus_foobar_bug:
        i++;
        goto _afnd_ofus_foobar_fish;
    _afnd_ofus_foobar_bad:
    {
        fprintf(fd, " %s", _afnd_ofus_foobar_fobar->_afnd_ofus_fobar_cyan[i]);
    }
        goto _afnd_ofus_foobar_bug;
    _afnd_ofus_foobar_gasp:;
    }
    fprintf(fd, "]\n");
    return;
}
int _afnd_ofus_bar_fobar(_afnd_ofus_clinton *_afnd_ofus_sex)
{
    {
        if (!(_afnd_ofus_sex ==
              NULL))
            goto _afnd_ofus_foobar_silly;
        return -1;
    _afnd_ofus_foobar_silly:;
    }
    return _afnd_ofus_sex->_afnd_ofus_nasa;
}
struct _afnd_ofus_full
{
    char *nombre;
    int tipo;
};
_afnd_ofus_fast *_afnd_ofus_small(char *nombre, int tipo)
{
    _afnd_ofus_fast *
        _afnd_ofus_ok;
    _afnd_ofus_ok = (_afnd_ofus_fast *)malloc(sizeof(_afnd_ofus_fast));
    _afnd_ofus_ok->nombre = (char *)malloc(strlen(nombre) + 1);
    strcpy(_afnd_ofus_ok->nombre, nombre);
    _afnd_ofus_ok->tipo = tipo;
    return _afnd_ofus_ok;
}
void _afnd_ofus_big(_afnd_ofus_fast *_afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok != NULL))
            goto _afnd_ofus_foobar_buggy;
        {
            {
                if (!(_afnd_ofus_ok->nombre != NULL))
                    goto _afnd_ofus_foobar_mum;
                {
                    free(_afnd_ofus_ok->nombre);
                    _afnd_ofus_ok->nombre = NULL;
                }
            _afnd_ofus_foobar_mum:;
            }
            free(_afnd_ofus_ok);
        }
    _afnd_ofus_foobar_buggy:;
    }
}
void _afnd_ofus_hello(FILE *fd, _afnd_ofus_fast *_afnd_ofus_ok)
{
    {
        if (!((_afnd_ofus_ok->tipo == INICIAL) || (_afnd_ofus_ok->tipo == INICIAL_Y_FINAL)))
            goto _afnd_ofus_foobar_dad;
        fprintf(fd, "->");
    _afnd_ofus_foobar_dad:;
    }
    fprintf(fd, "%s", _afnd_ofus_ok->nombre);
    {
        if (!((_afnd_ofus_ok->tipo == FINAL) || (_afnd_ofus_ok->tipo == INICIAL_Y_FINAL)))
            goto _afnd_ofus_foobar_disk;
        fprintf(fd, "*");
    _afnd_ofus_foobar_disk:;
    }
    fprintf(fd, " ");
    return;
}
int _afnd_ofus_bye(
    _afnd_ofus_fast *_afnd_ofus_ok, char *nombre)
{
    {
        if (!(strcmp(_afnd_ofus_ok->nombre,
                     nombre) == 0))
            goto _afnd_ofus_foobar_empty;
        return 1;
        goto _afnd_ofus_foobar_full;
    _afnd_ofus_foobar_empty:;
        return 0;
    _afnd_ofus_foobar_full:;
    }
}
_afnd_ofus_fast *
_afnd_ofus_speed(_afnd_ofus_fast *_afnd_ofus_ok)
{
    _afnd_ofus_fast *
        _afnd_ofus_baz_baz;
    _afnd_ofus_baz_baz = _afnd_ofus_small(_afnd_ofus_magic(
                                              _afnd_ofus_ok),
                                          _afnd_ofus_obscure(_afnd_ofus_ok));
    return _afnd_ofus_baz_baz;
}
char *_afnd_ofus_magic(_afnd_ofus_fast *_afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok == NULL))
            goto _afnd_ofus_foobar_fast;
        return NULL;
    _afnd_ofus_foobar_fast:;
    }
    return _afnd_ofus_ok->nombre;
}
int _afnd_ofus_obscure(_afnd_ofus_fast *_afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok == NULL))
            goto _afnd_ofus_foobar_small;
        return -1;
    _afnd_ofus_foobar_small:;
    }
    return _afnd_ofus_ok->tipo;
}
void _afnd_ofus_emacs(
    FILE *fd, _afnd_ofus_fast *_afnd_ofus_ok)
{
    {
        if (!((_afnd_ofus_obscure(_afnd_ofus_ok) == FINAL) || (_afnd_ofus_obscure(_afnd_ofus_ok) == INICIAL_Y_FINAL)))
            goto _afnd_ofus_foobar_big;
        {
            fprintf(fd, "\t%s [penwidth=\"2\"];\n", _afnd_ofus_ok->nombre);
        }
        goto _afnd_ofus_foobar_ok;
    _afnd_ofus_foobar_big:;
        {
            fprintf(fd,
                    "\t%s;\n", _afnd_ofus_ok->nombre);
        }
    _afnd_ofus_foobar_ok:;
    }
}
int _afnd_ofus_index(_afnd_ofus_fast *_afnd_ofus_bill, _afnd_ofus_fast *_afnd_ofus_joe) { return strcmp(_afnd_ofus_bill->nombre, _afnd_ofus_joe->nombre); }
struct _afnd_ofus_bar_fobaz
{
    char *nombre;
    int **_afnd_ofus_foobar_hello;
    int **_afnd_ofus_foobar_bye;
    int **
        _afnd_ofus_foobar_magic;
    int _afnd_ofus_bar_fred;
};
int **
_afnd_ofus_foobar_obscure(int _afnd_ofus_foobar_speed)
{
    int i;
    int j;
    int **
        _afnd_ofus_foobar_index;
    _afnd_ofus_foobar_index = (int **)malloc(
        _afnd_ofus_foobar_speed * sizeof(int *));
    {
        i = 0;
    _afnd_ofus_foobar_bill:
        if (!(i <
              _afnd_ofus_foobar_speed))
            goto _afnd_ofus_foobar_joe;
        goto _afnd_ofus_foobar_emacs;
    _afnd_ofus_foobar_vi:
        i++;
        goto _afnd_ofus_foobar_bill;
    _afnd_ofus_foobar_emacs:
    {
        _afnd_ofus_foobar_index[i] = (int *)malloc(
            _afnd_ofus_foobar_speed * sizeof(int));
    }
        goto _afnd_ofus_foobar_vi;
    _afnd_ofus_foobar_joe:;
    }
    {
        i = 0;
    _afnd_ofus_foobar_rms:
        if (!(i <
              _afnd_ofus_foobar_speed))
            goto _afnd_ofus_foobar_fbi;
        goto _afnd_ofus_foobar_cia;
    _afnd_ofus_foobar_nasa:
        i++;
        goto _afnd_ofus_foobar_rms;
    _afnd_ofus_foobar_cia:
    {
        {
            j = 0;
        _afnd_ofus_foobar_err:
            if (!(j < _afnd_ofus_foobar_speed))
                goto _afnd_ofus_foobar_google;
            goto _afnd_ofus_foobar_yahoo;
        _afnd_ofus_foobar_trick:
            j++;
            goto _afnd_ofus_foobar_err;
        _afnd_ofus_foobar_yahoo:
        {
            _afnd_ofus_foobar_index[i][j] = 0;
        }
            goto _afnd_ofus_foobar_trick;
        _afnd_ofus_foobar_google:;
        }
    }
        goto _afnd_ofus_foobar_nasa;
    _afnd_ofus_foobar_fbi:;
    }
    return _afnd_ofus_foobar_index;
}
void _afnd_ofus_foobar_hint(int **
                                _afnd_ofus_foobar_index,
                            int _afnd_ofus_foobar_speed)
{
    int i;
    {
        if (!(
                _afnd_ofus_foobar_index != NULL))
            goto _afnd_ofus_foobar_black;
        {
            {
                i = 0;
            _afnd_ofus_foobar_red:
                if (!(i < _afnd_ofus_foobar_speed))
                    goto _afnd_ofus_foobar_green;
                goto _afnd_ofus_foobar_yellow;
            _afnd_ofus_foobar_blue:
                i++;
                goto _afnd_ofus_foobar_red;
            _afnd_ofus_foobar_yellow:
            {
                free(
                    _afnd_ofus_foobar_index[i]);
            }
                goto _afnd_ofus_foobar_blue;
            _afnd_ofus_foobar_green:;
            }
        }
    _afnd_ofus_foobar_black:;
    }
    free(
        _afnd_ofus_foobar_index);
}
int **_afnd_ofus_foobar_magenta(int **
                                    _afnd_ofus_foobar_index,
                                int _afnd_ofus_foobar_speed)
{
    int **
        _afnd_ofus_foobar_cyan;
    int i, j;
    _afnd_ofus_foobar_cyan =
        _afnd_ofus_foobar_obscure(_afnd_ofus_foobar_speed);
    {
        i = 0;
    _afnd_ofus_foobar_white:
        if (!(i < _afnd_ofus_foobar_speed))
            goto _afnd_ofus_foobar_clinton;
        goto _afnd_ofus_foobar_bush;
    _afnd_ofus_foobar_jfk:
        i++;
        goto _afnd_ofus_foobar_white;
    _afnd_ofus_foobar_bush:
    {
        j = 0;
    _afnd_ofus_foobar_sex:
        if (!(j < _afnd_ofus_foobar_speed))
            goto _afnd_ofus_fobaz_foo;
        goto _afnd_ofus_fobaz_bar;
    _afnd_ofus_fobaz_baz:
        j++;
        goto _afnd_ofus_foobar_sex;
    _afnd_ofus_fobaz_bar:
    {
        _afnd_ofus_foobar_cyan[i][j] =
            _afnd_ofus_foobar_index[i][j];
    }
        goto _afnd_ofus_fobaz_baz;
    _afnd_ofus_fobaz_foo:;
    }
        goto _afnd_ofus_foobar_jfk;
    _afnd_ofus_foobar_clinton:;
    }
    return _afnd_ofus_foobar_cyan;
}
void _afnd_ofus_fobaz_fobar(FILE *fd, int **_afnd_ofus_foobar_index, int _afnd_ofus_foobar_speed)
{
    int i, j;
    {
        i = 0;
    _afnd_ofus_fobaz_foobar:
        if (!(i < _afnd_ofus_foobar_speed))
            goto _afnd_ofus_fobaz_fobaz;
        goto _afnd_ofus_fobaz_foobaz;
    _afnd_ofus_fobaz_quux:
        i++;
        goto _afnd_ofus_fobaz_foobar;
    _afnd_ofus_fobaz_foobaz:
    {
        fprintf(fd, "\n\t");
        {
            j = 0;
        _afnd_ofus_fobaz_fred:
            if (!(j < _afnd_ofus_foobar_speed))
                goto _afnd_ofus_fobaz_dog;
            goto _afnd_ofus_fobaz_cat;
        _afnd_ofus_fobaz_fish:
            j++;
            goto _afnd_ofus_fobaz_fred;
        _afnd_ofus_fobaz_cat:
        {
            fprintf(fd, "%d\t",
                    _afnd_ofus_foobar_index[i][j]);
        }
            goto _afnd_ofus_fobaz_fish;
        _afnd_ofus_fobaz_dog:;
        }
    }
        goto _afnd_ofus_fobaz_quux;
    _afnd_ofus_fobaz_fobaz:;
    }
    return;
}
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_quux(char *nombre, int
                                                             _afnd_ofus_bar_fred)
{
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat;
    int i, j;
    _afnd_ofus_bar_cat = (_afnd_ofus_bar_foobaz *)malloc(sizeof(_afnd_ofus_bar_foobaz));
    {
        if (!(nombre != NULL))
            goto _afnd_ofus_fobaz_gasp;
        {
            _afnd_ofus_bar_cat->nombre =
                (char *)malloc(sizeof(char) * (strlen(nombre) + 1));
            strcpy(_afnd_ofus_bar_cat->nombre, nombre);
        }
    _afnd_ofus_fobaz_gasp:;
    }
    _afnd_ofus_bar_cat->_afnd_ofus_bar_fred = _afnd_ofus_bar_fred;
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye = (int **)malloc(_afnd_ofus_bar_fred * sizeof(int *));
    {
        i = 0;
    _afnd_ofus_fobaz_bad:
        if (!(i < _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_bug;
        goto _afnd_ofus_fobaz_silly;
    _afnd_ofus_fobaz_buggy:
        i++;
        goto _afnd_ofus_fobaz_bad;
    _afnd_ofus_fobaz_silly:
    {
        _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i] = (int *)malloc(_afnd_ofus_bar_fred * sizeof(int));
    }
        goto _afnd_ofus_fobaz_buggy;
    _afnd_ofus_fobaz_bug:;
    }
    {
        i = 0;
    _afnd_ofus_fobaz_mum:
        if (!(i < _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_dad;
        goto _afnd_ofus_fobaz_disk;
    _afnd_ofus_fobaz_empty:
        i++;
        goto _afnd_ofus_fobaz_mum;
    _afnd_ofus_fobaz_disk:
    {
        {
            j = 0;
        _afnd_ofus_fobaz_full:
            if (!(j < _afnd_ofus_bar_fred))
                goto _afnd_ofus_fobaz_fast;
            goto _afnd_ofus_fobaz_small;
        _afnd_ofus_fobaz_big:
            j++;
            goto _afnd_ofus_fobaz_full;
        _afnd_ofus_fobaz_small:
        {
            _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i][j] = 0;
        }
            goto _afnd_ofus_fobaz_big;
        _afnd_ofus_fobaz_fast
            :;
        }
    }
        goto _afnd_ofus_fobaz_empty;
    _afnd_ofus_fobaz_dad:;
    }
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello = (int **)malloc(_afnd_ofus_bar_fred * sizeof(int *));
    {
        i = 0;
    _afnd_ofus_fobaz_ok:
        if (!(i < _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_hello;
        goto _afnd_ofus_fobaz_bye;
    _afnd_ofus_fobaz_magic:
        i++;
        goto _afnd_ofus_fobaz_ok;
    _afnd_ofus_fobaz_bye:
    {
        _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i] = (int *)
            malloc(_afnd_ofus_bar_fred * sizeof(int));
    }
        goto _afnd_ofus_fobaz_magic;
    _afnd_ofus_fobaz_hello:;
    }
    {
        i = 0;
    _afnd_ofus_fobaz_obscure:
        if (!(i <
              _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_speed;
        goto _afnd_ofus_fobaz_index;
    _afnd_ofus_fobaz_bill:
        i++;
        goto _afnd_ofus_fobaz_obscure;
    _afnd_ofus_fobaz_index
        :
    {
        {
            j = 0;
        _afnd_ofus_fobaz_joe:
            if (!(j < _afnd_ofus_bar_fred))
                goto _afnd_ofus_fobaz_emacs;
            goto _afnd_ofus_fobaz_vi;
        _afnd_ofus_fobaz_rms:
            j++;
            goto _afnd_ofus_fobaz_joe;
        _afnd_ofus_fobaz_vi:
        {
            _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][j] = 0;
        }
            goto _afnd_ofus_fobaz_rms;
        _afnd_ofus_fobaz_emacs:;
        }
    }
        goto _afnd_ofus_fobaz_bill;
    _afnd_ofus_fobaz_speed:;
    }
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic = (int **)malloc(_afnd_ofus_bar_fred *
                                                                 sizeof(int *));
    {
        i = 0;
    _afnd_ofus_fobaz_fbi:
        if (!(i < _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_cia;
        goto _afnd_ofus_fobaz_nasa;
    _afnd_ofus_fobaz_err:
        i++;
        goto _afnd_ofus_fobaz_fbi;
    _afnd_ofus_fobaz_nasa:
    {
        _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i] = (int *)malloc(_afnd_ofus_bar_fred * sizeof(int));
    }
        goto _afnd_ofus_fobaz_err;
    _afnd_ofus_fobaz_cia:;
    }
    {
        i = 0;
    _afnd_ofus_fobaz_google:
        if (!(i < _afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_yahoo;
        goto _afnd_ofus_fobaz_trick;
    _afnd_ofus_fobaz_hint:
        i++;
        goto _afnd_ofus_fobaz_google;
    _afnd_ofus_fobaz_trick:
    {
        {
            j = 0;
        _afnd_ofus_fobaz_black:
            if (!(j < _afnd_ofus_bar_fred))
                goto _afnd_ofus_fobaz_red;
            goto _afnd_ofus_fobaz_green;
        _afnd_ofus_fobaz_yellow:
            j++;
            goto _afnd_ofus_fobaz_black;
        _afnd_ofus_fobaz_green
            :
        {
            _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j] = 0;
        }
            goto _afnd_ofus_fobaz_yellow;
        _afnd_ofus_fobaz_red:;
        }
    }
        goto _afnd_ofus_fobaz_hint;
    _afnd_ofus_fobaz_yahoo:;
    }
    return _afnd_ofus_bar_cat;
}
void _afnd_ofus_bar_dog(
    FILE *fd, _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    int i, j;
    {
        if (!(
                _afnd_ofus_bar_cat->nombre != NULL))
            goto _afnd_ofus_fobaz_blue;
        fprintf(fd,
                "%s={\n\t", _afnd_ofus_bar_cat->nombre);
    _afnd_ofus_fobaz_blue:;
    }
    {
        j = 0;
    _afnd_ofus_fobaz_magenta:
        if (!(j < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_cyan;
        goto _afnd_ofus_fobaz_white;
    _afnd_ofus_fobaz_clinton:
        j++;
        goto _afnd_ofus_fobaz_magenta;
    _afnd_ofus_fobaz_white:
        fprintf(fd, "\t[%d]", j);
        goto _afnd_ofus_fobaz_clinton;
    _afnd_ofus_fobaz_cyan:;
    }
    fprintf(fd, "\n");
    fprintf(fd, "\t\tCIERRE\n");
    {
        i = 0;
    _afnd_ofus_fobaz_bush:
        if (!(i < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_fobaz_jfk;
        goto _afnd_ofus_fobaz_sex;
    _afnd_ofus_foobaz_foo:
        i++;
        goto _afnd_ofus_fobaz_bush;
    _afnd_ofus_fobaz_sex:
    {
        fprintf(fd, "\t[%d]", i);
        {
            j = 0;
        _afnd_ofus_foobaz_bar:
            if (!(j < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                goto _afnd_ofus_foobaz_baz;
            goto _afnd_ofus_foobaz_fobar;
        _afnd_ofus_foobaz_foobar:
            j++;
            goto _afnd_ofus_foobaz_bar;
        _afnd_ofus_foobaz_fobar:
        {
            fprintf(fd, "\t%d", _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j]);
        }
            goto _afnd_ofus_foobaz_foobar;
        _afnd_ofus_foobaz_baz:;
        }
        fprintf(fd, "\n");
    }
        goto _afnd_ofus_foobaz_foo;
    _afnd_ofus_fobaz_jfk:;
    }
    fprintf(fd, "\n");
    fprintf(fd, "\t\tPOTENCIA i\n");
    {
        i = 0;
    _afnd_ofus_foobaz_fobaz:
        if (!(i < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_foobaz_foobaz;
        goto _afnd_ofus_foobaz_quux;
    _afnd_ofus_foobaz_fred:
        i++;
        goto _afnd_ofus_foobaz_fobaz;
    _afnd_ofus_foobaz_quux:
    {
        fprintf(fd, "\t[%d]", i);
        {
            j = 0;
        _afnd_ofus_foobaz_dog:
            if (!(j < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                goto _afnd_ofus_foobaz_cat;
            goto _afnd_ofus_foobaz_fish;
        _afnd_ofus_foobaz_gasp:
            j++;
            goto _afnd_ofus_foobaz_dog;
        _afnd_ofus_foobaz_fish:
        {
            fprintf(fd, "\t%d",
                    _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][j]);
        }
            goto _afnd_ofus_foobaz_gasp;
        _afnd_ofus_foobaz_cat:;
        }
        fprintf(fd, "\n");
    }
        goto _afnd_ofus_foobaz_fred;
    _afnd_ofus_foobaz_foobaz:;
    }
    fprintf(fd, "\n");
    fprintf(fd,
            "\t\tRELACION INICIAL i\n");
    {
        i = 0;
    _afnd_ofus_foobaz_bad:
        if (!(i <
              _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_foobaz_bug;
        goto _afnd_ofus_foobaz_silly;
    _afnd_ofus_foobaz_buggy:
        i++;
        goto _afnd_ofus_foobaz_bad;
    _afnd_ofus_foobaz_silly:
    {
        fprintf(fd, "\t[%d]", i);
        {
            j = 0;
        _afnd_ofus_foobaz_mum:
            if (!(j < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                goto _afnd_ofus_foobaz_dad;
            goto _afnd_ofus_foobaz_disk;
        _afnd_ofus_foobaz_empty:
            j++;
            goto _afnd_ofus_foobaz_mum;
        _afnd_ofus_foobaz_disk:
        {
            fprintf(fd, "\t%d", _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i][j]);
        }
            goto _afnd_ofus_foobaz_empty;
        _afnd_ofus_foobaz_dad:;
        }
        fprintf(fd, "\n");
    }
        goto _afnd_ofus_foobaz_buggy;
    _afnd_ofus_foobaz_bug:;
    }
    fprintf(fd, "}\n");
    return;
}
void _afnd_ofus_bar_fish(
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    int i;
    {
        if (!(_afnd_ofus_bar_cat->nombre != NULL))
            goto _afnd_ofus_foobaz_full;
        free(_afnd_ofus_bar_cat->nombre);
    _afnd_ofus_foobaz_full:;
    }
    {
        if (!(_afnd_ofus_bar_cat->_afnd_ofus_foobar_bye != NULL))
            goto _afnd_ofus_foobaz_fast;
        {
            {
                i = 0;
            _afnd_ofus_foobaz_small:
                if (!(i <
                      _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                    goto _afnd_ofus_foobaz_big;
                goto _afnd_ofus_foobaz_ok;
            _afnd_ofus_foobaz_hello:
                i++;
                goto _afnd_ofus_foobaz_small;
            _afnd_ofus_foobaz_ok:
            {
                free(_afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i]);
            }
                goto _afnd_ofus_foobaz_hello;
            _afnd_ofus_foobaz_big:;
            }
        }
    _afnd_ofus_foobaz_fast:;
    }
    free(_afnd_ofus_bar_cat->_afnd_ofus_foobar_bye);
    {
        if (!(_afnd_ofus_bar_cat->_afnd_ofus_foobar_hello != NULL))
            goto _afnd_ofus_foobaz_bye;
        {
            {
                i = 0;
            _afnd_ofus_foobaz_magic:
                if (!(i < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                    goto _afnd_ofus_foobaz_obscure;
                goto _afnd_ofus_foobaz_speed;
            _afnd_ofus_foobaz_index
                :
                i++;
                goto _afnd_ofus_foobaz_magic;
            _afnd_ofus_foobaz_speed:
            {
                free(
                    _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i]);
            }
                goto _afnd_ofus_foobaz_index;
            _afnd_ofus_foobaz_obscure:;
            }
        }
    _afnd_ofus_foobaz_bye:;
    }
    free(_afnd_ofus_bar_cat->_afnd_ofus_foobar_hello);
    {
        if (!(_afnd_ofus_bar_cat->_afnd_ofus_foobar_magic !=
              NULL))
            goto _afnd_ofus_foobaz_bill;
        {
            {
                i = 0;
            _afnd_ofus_foobaz_joe:
                if (!(i <
                      _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                    goto _afnd_ofus_foobaz_emacs;
                goto _afnd_ofus_foobaz_vi;
            _afnd_ofus_foobaz_rms:
                i++;
                goto _afnd_ofus_foobaz_joe;
            _afnd_ofus_foobaz_vi:
            {
                free(_afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i]);
            }
                goto _afnd_ofus_foobaz_rms;
            _afnd_ofus_foobaz_emacs:;
            }
        }
    _afnd_ofus_foobaz_bill:;
    }
    free(_afnd_ofus_bar_cat->_afnd_ofus_foobar_magic);
    free(_afnd_ofus_bar_cat);
    return;
}
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_bug(_afnd_ofus_bar_foobaz *
                                              _afnd_ofus_bar_cat,
                                          int i, int j)
{
    {
        if (!(_afnd_ofus_bar_cat == NULL))
            goto _afnd_ofus_foobaz_fbi;
        return _afnd_ofus_bar_cat;
    _afnd_ofus_foobaz_fbi:;
    }
    {
        if (!(
                (_afnd_ofus_bar_cat->_afnd_ofus_bar_fred <= i) || (_afnd_ofus_bar_cat->_afnd_ofus_bar_fred <= j)))
            goto _afnd_ofus_foobaz_cia;
        {
            fprintf(stdout,
                    "Fuera de rango %d %d \n", i, j);
            return _afnd_ofus_bar_cat;
        }
    _afnd_ofus_foobaz_cia:;
    }
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i][j] = 1;
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][j] = 1;
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j] = 1;
    return _afnd_ofus_bar_cat;
}
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_gasp(_afnd_ofus_bar_foobaz *
                                               _afnd_ofus_bar_cat)
{
    _afnd_ofus_bar_foobaz *_afnd_ofus_foobaz_nasa;
    int i, j;
    char *
        nombre;
    {
        if (!(_afnd_ofus_bar_cat == NULL))
            goto _afnd_ofus_foobaz_err;
        return NULL;
    _afnd_ofus_foobaz_err:;
    }
    nombre = (char *)malloc((strlen(_afnd_ofus_bar_cat->nombre) + 2) * sizeof(char));
    strcpy(nombre, _afnd_ofus_bar_cat->nombre);
    strcat(
        nombre, "'");
    _afnd_ofus_foobaz_nasa = _afnd_ofus_bar_quux(nombre,
                                                 _afnd_ofus_bar_cat->_afnd_ofus_bar_fred);
    free(nombre);
    _afnd_ofus_foobaz_nasa->_afnd_ofus_bar_fred = _afnd_ofus_bar_cat->_afnd_ofus_bar_fred;
    {
        i = 0;
    _afnd_ofus_foobaz_google:
        if (!(i < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_foobaz_yahoo;
        goto _afnd_ofus_foobaz_trick;
    _afnd_ofus_foobaz_hint:
        i++;
        goto _afnd_ofus_foobaz_google;
    _afnd_ofus_foobaz_trick:
    {
        {
            j = 0;
        _afnd_ofus_foobaz_black:
            if (!(j < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                goto _afnd_ofus_foobaz_red;
            goto _afnd_ofus_foobaz_green;
        _afnd_ofus_foobaz_yellow:
            j++;
            goto _afnd_ofus_foobaz_black;
        _afnd_ofus_foobaz_green:
        {
            _afnd_ofus_foobaz_nasa->_afnd_ofus_foobar_bye[i][j] = _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i][j];
            _afnd_ofus_foobaz_nasa->_afnd_ofus_foobar_hello[i]
                                                           [j] = _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][j];
            _afnd_ofus_foobaz_nasa->_afnd_ofus_foobar_magic[i][j] = _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j];
        }
            goto _afnd_ofus_foobaz_yellow;
        _afnd_ofus_foobaz_red:;
        }
    }
        goto _afnd_ofus_foobaz_hint;
    _afnd_ofus_foobaz_yahoo:;
    }
    return _afnd_ofus_foobaz_nasa;
}
int _afnd_ofus_bar_buggy(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    {
        if (!(
                _afnd_ofus_bar_cat != NULL))
            goto _afnd_ofus_foobaz_blue;
        return _afnd_ofus_bar_cat->_afnd_ofus_bar_fred;
        goto _afnd_ofus_foobaz_magenta;
    _afnd_ofus_foobaz_blue:;
        return -1;
    _afnd_ofus_foobaz_magenta:;
    }
}
int _afnd_ofus_bar_silly(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    int i, j,
        _afnd_ofus_foobaz_cyan;
    int _afnd_ofus_foobaz_white = 0;
    int **
        _afnd_ofus_foobaz_clinton;
    _afnd_ofus_foobaz_clinton = _afnd_ofus_foobar_obscure(
        _afnd_ofus_bar_cat->_afnd_ofus_bar_fred);
    _afnd_ofus_bar_cat->nombre = (char *)
        realloc(_afnd_ofus_bar_cat->nombre, (strlen(_afnd_ofus_bar_cat->nombre) + 2) *
                                                sizeof(char));
    strcat(_afnd_ofus_bar_cat->nombre, "+");
    {
        i = 0;
    _afnd_ofus_foobaz_bush:
        if (!(i < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
            goto _afnd_ofus_foobaz_jfk;
        goto _afnd_ofus_foobaz_sex;
    _afnd_ofus_quux_foo:
        i++;
        goto _afnd_ofus_foobaz_bush;
    _afnd_ofus_foobaz_sex:
    {
        {
            j = 0;
        _afnd_ofus_quux_bar:
            if (!(j <
                  _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                goto _afnd_ofus_quux_baz;
            goto _afnd_ofus_quux_fobar;
        _afnd_ofus_quux_foobar:
            j++;
            goto _afnd_ofus_quux_bar;
        _afnd_ofus_quux_fobar:
        {
            {
                _afnd_ofus_foobaz_cyan = 0;
            _afnd_ofus_quux_fobaz:
                if (!(
                        _afnd_ofus_foobaz_cyan < _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                    goto _afnd_ofus_quux_foobaz;
                goto _afnd_ofus_quux_quux;
            _afnd_ofus_quux_fred:
                _afnd_ofus_foobaz_cyan++;
                goto _afnd_ofus_quux_fobaz;
            _afnd_ofus_quux_quux:
            {
                {
                    if (
                        !((_afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][_afnd_ofus_foobaz_cyan] ==
                           _afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[_afnd_ofus_foobaz_cyan][j]) &&
                          (_afnd_ofus_bar_cat->_afnd_ofus_foobar_hello[i][_afnd_ofus_foobaz_cyan] == 1)))
                        goto _afnd_ofus_quux_dog;
                    {
                        _afnd_ofus_foobaz_clinton[i][j] = 1;
                        {
                            if (!(
                                    _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j] == 0))
                                goto _afnd_ofus_quux_cat;
                            {
                                _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j] = 1;
                                _afnd_ofus_foobaz_white++;
                            }
                        _afnd_ofus_quux_cat:;
                        }
                        goto _afnd_ofus_quux_foobaz;
                    }
                _afnd_ofus_quux_dog:;
                }
            }
                goto _afnd_ofus_quux_fred;
            _afnd_ofus_quux_foobaz:;
            }
        }
            goto _afnd_ofus_quux_foobar;
        _afnd_ofus_quux_baz:;
        }
    }
        goto _afnd_ofus_quux_foo;
    _afnd_ofus_foobaz_jfk:;
    }
    _afnd_ofus_foobar_hint(_afnd_ofus_bar_cat->_afnd_ofus_foobar_hello, _afnd_ofus_bar_cat->_afnd_ofus_bar_fred);
    _afnd_ofus_bar_cat->_afnd_ofus_foobar_hello = _afnd_ofus_foobaz_clinton;
    return _afnd_ofus_foobaz_white;
}
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_mum(
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    int i;
    {
        if (!(_afnd_ofus_bar_cat == NULL))
            goto _afnd_ofus_quux_fish;
        return NULL;
        goto _afnd_ofus_quux_gasp;
    _afnd_ofus_quux_fish:;
        {
            _afnd_ofus_bar_cat->nombre = (char *)realloc(
                _afnd_ofus_bar_cat->nombre, (strlen(_afnd_ofus_bar_cat->nombre) + 2) * sizeof(char));
            strcat(_afnd_ofus_bar_cat->nombre, "*");
            {
                i = 0;
            _afnd_ofus_quux_bad:
                if (!(i <
                      _afnd_ofus_bar_cat->_afnd_ofus_bar_fred))
                    goto _afnd_ofus_quux_bug;
                goto _afnd_ofus_quux_silly;
            _afnd_ofus_quux_buggy:
                i++;
                goto _afnd_ofus_quux_bad;
            _afnd_ofus_quux_silly:
            {
                _afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][i] = 1;
            }
                goto _afnd_ofus_quux_buggy;
            _afnd_ofus_quux_bug:;
            }
        }
    _afnd_ofus_quux_gasp:;
    }
    return _afnd_ofus_bar_cat;
}
_afnd_ofus_bar_foobaz *_afnd_ofus_bar_dad(
    _afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat)
{
    int _afnd_ofus_foobaz_white = -1;
    {
    _afnd_ofus_quux_mum:
        if (!(_afnd_ofus_foobaz_white != 0))
            goto _afnd_ofus_quux_dad;
        {
            _afnd_ofus_foobaz_white = _afnd_ofus_bar_silly(_afnd_ofus_bar_cat);
        }
        goto _afnd_ofus_quux_mum;
    _afnd_ofus_quux_dad:;
    }
    return _afnd_ofus_bar_cat;
}
int _afnd_ofus_bar_disk(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat, int i, int j)
{
    {
        if (
            !((i >= _afnd_ofus_bar_cat->_afnd_ofus_bar_fred) || (j >= _afnd_ofus_bar_cat->_afnd_ofus_bar_fred)))
            goto _afnd_ofus_quux_disk;
        {
            return -1;
        }
    _afnd_ofus_quux_disk:;
    }
    return (_afnd_ofus_bar_cat->_afnd_ofus_foobar_bye[i][j] == 1);
}
int _afnd_ofus_bar_empty(_afnd_ofus_bar_foobaz *_afnd_ofus_bar_cat, int i,
                         int j)
{
    {
        if (!((i >= _afnd_ofus_bar_cat->_afnd_ofus_bar_fred) || (j >=
                                                                 _afnd_ofus_bar_cat->_afnd_ofus_bar_fred)))
            goto _afnd_ofus_quux_empty;
        {
            return -1;
        }
    _afnd_ofus_quux_empty:;
    }
    return (_afnd_ofus_bar_cat->_afnd_ofus_foobar_magic[i][j] == 1);
}
struct _afnd_ofus_quux_full
{
    char *_afnd_ofus_quux_fast;
    char *simbolo;
    char *_afnd_ofus_quux_small;
};
typedef struct _afnd_ofus_quux_full
    _afnd_ofus_quux_big;
_afnd_ofus_fast *_afnd_ofus_quux_ok(AFND *p_afnd, int pos);
typedef int *_afnd_ofus_quux_hello;
struct _afnd_ofus_quux_bye
{
    int
        _afnd_ofus_nasa;
    _afnd_ofus_quux_hello _afnd_ofus_quux_magic;
};
typedef struct
    _afnd_ofus_quux_bye _afnd_ofus_quux_obscure;
_afnd_ofus_quux_big *
_afnd_ofus_quux_speed(char *_afnd_ofus_quux_fast, char *simbolo, char *_afnd_ofus_quux_small)
{
    _afnd_ofus_quux_big *_afnd_ofus_baz_baz;
    _afnd_ofus_baz_baz = (_afnd_ofus_quux_big *)malloc(sizeof(_afnd_ofus_quux_big));
    _afnd_ofus_baz_baz->_afnd_ofus_quux_fast = _afnd_ofus_fred(_afnd_ofus_quux_fast);
    _afnd_ofus_baz_baz->simbolo = _afnd_ofus_fred(simbolo);
    _afnd_ofus_baz_baz->_afnd_ofus_quux_small = _afnd_ofus_fred(_afnd_ofus_quux_small);
    return _afnd_ofus_baz_baz;
}
char *_afnd_ofus_quux_index(_afnd_ofus_quux_big *
                                _afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok == NULL))
            goto _afnd_ofus_quux_bill;
        return NULL;
    _afnd_ofus_quux_bill:;
    }
    return _afnd_ofus_ok->_afnd_ofus_quux_fast;
}
char *
_afnd_ofus_quux_joe(_afnd_ofus_quux_big *_afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok ==
              NULL))
            goto _afnd_ofus_quux_emacs;
        return NULL;
    _afnd_ofus_quux_emacs:;
    }
    return _afnd_ofus_ok->simbolo;
}
char *_afnd_ofus_quux_vi(_afnd_ofus_quux_big *
                             _afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok == NULL))
            goto _afnd_ofus_quux_rms;
        return NULL;
    _afnd_ofus_quux_rms:;
    }
    return _afnd_ofus_ok->_afnd_ofus_quux_small;
}
void _afnd_ofus_quux_fbi(_afnd_ofus_quux_big *_afnd_ofus_ok)
{
    {
        if (!(_afnd_ofus_ok !=
              NULL))
            goto _afnd_ofus_quux_cia;
        {
            {
                if (!(_afnd_ofus_ok->_afnd_ofus_quux_fast !=
                      NULL))
                    goto _afnd_ofus_quux_nasa;
                {
                    free(_afnd_ofus_ok->_afnd_ofus_quux_fast);
                    _afnd_ofus_ok->_afnd_ofus_quux_fast = NULL;
                }
            _afnd_ofus_quux_nasa:;
            }
            {
                if (!(
                        _afnd_ofus_ok->simbolo != NULL))
                    goto _afnd_ofus_quux_err;
                {
                    free(_afnd_ofus_ok->simbolo);
                    _afnd_ofus_ok->simbolo = NULL;
                }
            _afnd_ofus_quux_err:;
            }
            {
                if (!(
                        _afnd_ofus_ok->_afnd_ofus_quux_small != NULL))
                    goto _afnd_ofus_quux_google;
                {
                    free(
                        _afnd_ofus_ok->_afnd_ofus_quux_small);
                    _afnd_ofus_ok->_afnd_ofus_quux_small =
                        NULL;
                }
            _afnd_ofus_quux_google:;
            }
            free(_afnd_ofus_ok);
        }
    _afnd_ofus_quux_cia:;
    }
}
_afnd_ofus_quux_big *_afnd_ofus_quux_yahoo(_afnd_ofus_quux_big *_afnd_ofus_ok)
{
    _afnd_ofus_quux_big *_afnd_ofus_baz_baz;
    _afnd_ofus_baz_baz =
        _afnd_ofus_quux_speed(_afnd_ofus_quux_index(_afnd_ofus_ok), _afnd_ofus_quux_joe(_afnd_ofus_ok), _afnd_ofus_quux_vi(_afnd_ofus_ok));
    return _afnd_ofus_baz_baz;
}
void _afnd_ofus_quux_trick(FILE *fd, _afnd_ofus_quux_big *_afnd_ofus_ok)
{
    fprintf(
        fd, "Estado Inicial: %s\n", _afnd_ofus_ok->_afnd_ofus_quux_fast);
    fprintf(fd,
            "Simbolo: %s\n", _afnd_ofus_ok->simbolo);
    fprintf(fd, "Estado final: %s\n",
            _afnd_ofus_ok->_afnd_ofus_quux_small);
    return;
}
int _afnd_ofus_quux_hint(
    _afnd_ofus_quux_big *_afnd_ofus_quux_black, _afnd_ofus_quux_big *
                                                    _afnd_ofus_quux_red)
{
    int _afnd_ofus_quux_green, _afnd_ofus_quux_yellow,
        _afnd_ofus_quux_blue;
    _afnd_ofus_quux_green = strcmp(_afnd_ofus_quux_black->_afnd_ofus_quux_fast, _afnd_ofus_quux_red->_afnd_ofus_quux_fast);
    _afnd_ofus_quux_yellow = strcmp(_afnd_ofus_quux_black->simbolo,
                                    _afnd_ofus_quux_red->simbolo);
    _afnd_ofus_quux_blue = strcmp(
        _afnd_ofus_quux_black->_afnd_ofus_quux_small, _afnd_ofus_quux_red->_afnd_ofus_quux_small);
    {
        if (!(_afnd_ofus_quux_green == 0))
            goto _afnd_ofus_quux_magenta;
        {
            {
                if (!(_afnd_ofus_quux_yellow == 0))
                    goto _afnd_ofus_quux_cyan;
                {
                    return _afnd_ofus_quux_blue;
                }
                goto _afnd_ofus_quux_white;
            _afnd_ofus_quux_cyan:;
                return _afnd_ofus_quux_yellow;
            _afnd_ofus_quux_white:;
            }
        }
        goto _afnd_ofus_quux_clinton;
    _afnd_ofus_quux_magenta:;
        return _afnd_ofus_quux_green;
    _afnd_ofus_quux_clinton:;
    }
}
int _afnd_ofus_quux_bush(
    const _afnd_ofus_quux_obscure *_afnd_ofus_quux_jfk)
{
    {
        if (!(_afnd_ofus_quux_jfk ==
              NULL))
            goto _afnd_ofus_quux_sex;
        return -1;
    _afnd_ofus_quux_sex:;
    }
    return _afnd_ofus_quux_jfk->_afnd_ofus_nasa;
}
_afnd_ofus_quux_obscure *
_afnd_ofus_fred_foo(int _afnd_ofus_nasa)
{
    _afnd_ofus_quux_obscure *
        _afnd_ofus_baz_baz;
    int i;
    _afnd_ofus_baz_baz = (_afnd_ofus_quux_obscure *)malloc(
        sizeof(_afnd_ofus_quux_obscure));
    _afnd_ofus_baz_baz->_afnd_ofus_quux_magic = (_afnd_ofus_quux_hello)malloc(sizeof(int) * _afnd_ofus_nasa);
    _afnd_ofus_baz_baz->_afnd_ofus_nasa = _afnd_ofus_nasa;
    {
        i = 0;
    _afnd_ofus_fred_bar:
        if (!(i <
              _afnd_ofus_nasa))
            goto _afnd_ofus_fred_baz;
        goto _afnd_ofus_fred_fobar;
    _afnd_ofus_fred_foobar:
        i++;
        goto _afnd_ofus_fred_bar;
    _afnd_ofus_fred_fobar:
        _afnd_ofus_baz_baz->_afnd_ofus_quux_magic[i] = 0;
        goto _afnd_ofus_fred_foobar;
    _afnd_ofus_fred_baz:;
    }
    return _afnd_ofus_baz_baz;
}
_afnd_ofus_quux_obscure *
_afnd_ofus_fred_fobaz(_afnd_ofus_quux_obscure *_afnd_ofus_fred_foobaz)
{
    _afnd_ofus_quux_obscure *_afnd_ofus_baz_baz;
    int i;
    _afnd_ofus_baz_baz =
        _afnd_ofus_fred_foo(_afnd_ofus_fred_foobaz->_afnd_ofus_nasa);
    {
        i = 0;
    _afnd_ofus_fred_quux:
        if (!(i < _afnd_ofus_fred_foobaz->_afnd_ofus_nasa))
            goto _afnd_ofus_fred_fred;
        goto _afnd_ofus_fred_dog;
    _afnd_ofus_fred_cat:
        i++;
        goto _afnd_ofus_fred_quux;
    _afnd_ofus_fred_dog:
    {
        {
            if (!(_afnd_ofus_fred_foobaz->_afnd_ofus_quux_magic[i] == 1))
                goto _afnd_ofus_fred_fish;
            {
                _afnd_ofus_baz_baz->_afnd_ofus_quux_magic[i] = 1;
            }
        _afnd_ofus_fred_fish:;
        }
    }
        goto _afnd_ofus_fred_cat;
    _afnd_ofus_fred_fred:;
    }
    return _afnd_ofus_baz_baz;
}
int _afnd_ofus_fred_gasp(
    const _afnd_ofus_quux_obscure *_afnd_ofus_fred_foobaz, const _afnd_ofus_quux_obscure *_afnd_ofus_fred_bad)
{
    int i;
    {
        if (!(_afnd_ofus_quux_bush(
                  _afnd_ofus_fred_foobaz) != _afnd_ofus_quux_bush(_afnd_ofus_fred_bad)))
            goto _afnd_ofus_fred_bug;
        return _afnd_ofus_quux_bush(_afnd_ofus_fred_foobaz) -
               _afnd_ofus_quux_bush(_afnd_ofus_fred_bad);
    _afnd_ofus_fred_bug:;
    }
    {
        i = 0;
    _afnd_ofus_fred_silly:
        if (!(i < _afnd_ofus_quux_bush(_afnd_ofus_fred_foobaz)))
            goto _afnd_ofus_fred_buggy;
        goto _afnd_ofus_fred_mum;
    _afnd_ofus_fred_dad:
        i++;
        goto _afnd_ofus_fred_silly;
    _afnd_ofus_fred_mum:
    {
        {
            if (!(_afnd_ofus_fred_foobaz->_afnd_ofus_quux_magic[i] != _afnd_ofus_fred_bad->_afnd_ofus_quux_magic[i]))
                goto _afnd_ofus_fred_disk;
            {
                return 1;
            }
        _afnd_ofus_fred_disk:;
        }
    }
        goto _afnd_ofus_fred_dad;
    _afnd_ofus_fred_buggy:;
    }
    return 0;
}
void _afnd_ofus_fred_empty(_afnd_ofus_quux_obscure *_afnd_ofus_fred_full)
{
    {
        if (!(
                _afnd_ofus_fred_full == NULL))
            goto _afnd_ofus_fred_fast;
        return;
    _afnd_ofus_fred_fast:;
    }
    {
        if (!(_afnd_ofus_fred_full->_afnd_ofus_quux_magic != NULL))
            goto _afnd_ofus_fred_small;
        free(_afnd_ofus_fred_full->_afnd_ofus_quux_magic);
    _afnd_ofus_fred_small:;
    }
    free(_afnd_ofus_fred_full);
}
int _afnd_ofus_fred_big(
    _afnd_ofus_quux_obscure *_afnd_ofus_fred_full)
{
    int i;
    {
        if (!(_afnd_ofus_fred_full == NULL))
            goto _afnd_ofus_fred_ok;
        return 1;
    _afnd_ofus_fred_ok:;
    }
    {
        if (!(
                _afnd_ofus_fred_full->_afnd_ofus_nasa == 0))
            goto _afnd_ofus_fred_hello;
        return 1;
    _afnd_ofus_fred_hello:;
    }
    {
        i = 0;
    _afnd_ofus_fred_bye:
        if (!(i < _afnd_ofus_fred_full->_afnd_ofus_nasa))
            goto _afnd_ofus_fred_magic;
        goto _afnd_ofus_fred_obscure;
    _afnd_ofus_fred_speed:
        i++;
        goto _afnd_ofus_fred_bye;
    _afnd_ofus_fred_obscure:
    {
        {
            if (!(_afnd_ofus_fred_full->_afnd_ofus_quux_magic[i] != 0))
                goto _afnd_ofus_fred_index;
            goto _afnd_ofus_fred_magic;
        _afnd_ofus_fred_index:;
        }
    }
        goto _afnd_ofus_fred_speed;
    _afnd_ofus_fred_magic:;
    }
    return (i == _afnd_ofus_fred_full
                     ->_afnd_ofus_nasa);
}
_afnd_ofus_quux_hello _afnd_ofus_fred_bill(int
                                               _afnd_ofus_nasa)
{
    _afnd_ofus_quux_hello _afnd_ofus_fred_joe;
    int i;
    _afnd_ofus_fred_joe = (int *)malloc(sizeof(int) * _afnd_ofus_nasa);
    {
        i = 0;
    _afnd_ofus_fred_emacs:
        if (!(i < _afnd_ofus_nasa))
            goto _afnd_ofus_fred_vi;
        goto _afnd_ofus_fred_rms;
    _afnd_ofus_fred_fbi:
        i++;
        goto _afnd_ofus_fred_emacs;
    _afnd_ofus_fred_rms:
        _afnd_ofus_fred_joe[i] = 0;
        goto _afnd_ofus_fred_fbi;
    _afnd_ofus_fred_vi:;
    }
    return _afnd_ofus_fred_joe;
}
_afnd_ofus_quux_hello
_afnd_ofus_fred_cia(_afnd_ofus_quux_hello _afnd_ofus_fred_nasa)
{
    int i;
    _afnd_ofus_quux_hello _afnd_ofus_fred_err;
    int _afnd_ofus_nasa;
    _afnd_ofus_nasa =
        sizeof(_afnd_ofus_fred_nasa) / sizeof(_afnd_ofus_fred_nasa[0]);
    _afnd_ofus_fred_err = _afnd_ofus_fred_bill(_afnd_ofus_nasa);
    {
        i = 0;
    _afnd_ofus_fred_google:
        if (!(_afnd_ofus_fred_nasa[i] != 0))
            goto _afnd_ofus_fred_yahoo;
        goto _afnd_ofus_fred_trick;
    _afnd_ofus_fred_hint:
        i++;
        goto _afnd_ofus_fred_google;
    _afnd_ofus_fred_trick:
    {
        {
            if (!(_afnd_ofus_fred_nasa[i] ==
                  1))
                goto _afnd_ofus_fred_black;
            {
                _afnd_ofus_fred_err[i] = 1;
            }
        _afnd_ofus_fred_black
            :;
        }
    }
        goto _afnd_ofus_fred_hint;
    _afnd_ofus_fred_yahoo:;
    }
    return _afnd_ofus_fred_err;
}
void *_afnd_ofus_fred_red(_afnd_ofus_quux_hello
                              _afnd_ofus_fred_nasa)
{
    int i;
    int _afnd_ofus_nasa;
    _afnd_ofus_quux_hello
        _afnd_ofus_fred_err;
    _afnd_ofus_nasa = 0;
    {
        i = 0;
    _afnd_ofus_fred_green:
        if (!(
                _afnd_ofus_fred_nasa[i] < 2))
            goto _afnd_ofus_fred_yellow;
        goto _afnd_ofus_fred_blue;
    _afnd_ofus_fred_magenta:
        i++;
        goto _afnd_ofus_fred_green;
    _afnd_ofus_fred_blue:
    {
        _afnd_ofus_nasa++;
    }
        goto _afnd_ofus_fred_magenta;
    _afnd_ofus_fred_yellow:;
    }
    fprintf(stdout, "==========> TAMANO %d\n",
            _afnd_ofus_nasa);
    _afnd_ofus_fred_err = _afnd_ofus_fred_bill(_afnd_ofus_nasa);
    {
        i =
            0;
    _afnd_ofus_fred_cyan:
        if (!(_afnd_ofus_fred_nasa[i] < 2))
            goto _afnd_ofus_fred_white;
        goto _afnd_ofus_fred_clinton;
    _afnd_ofus_fred_bush:
        i++;
        goto _afnd_ofus_fred_cyan;
    _afnd_ofus_fred_clinton:
    {
        _afnd_ofus_fred_err[i] =
            _afnd_ofus_fred_nasa[i];
    }
        goto _afnd_ofus_fred_bush;
    _afnd_ofus_fred_white:;
    }
    return _afnd_ofus_fred_err;
}
int _afnd_ofus_fred_jfk(const int *
                            _afnd_ofus_fred_nasa,
                        const int *_afnd_ofus_fred_sex)
{
    int i;
    {
        i = 0;
    _afnd_ofus_dog_foo:
        if (!(i < 6))
            goto _afnd_ofus_dog_bar;
        goto _afnd_ofus_dog_baz;
    _afnd_ofus_dog_fobar:
        i++;
        goto _afnd_ofus_dog_foo;
    _afnd_ofus_dog_baz:
    {
        {
            if (!(
                    _afnd_ofus_fred_nasa[i] != _afnd_ofus_fred_sex[i]))
                goto _afnd_ofus_dog_foobar;
            {
                return 1;
            }
        _afnd_ofus_dog_foobar:;
        }
    }
        goto _afnd_ofus_dog_fobar;
    _afnd_ofus_dog_bar:;
    }
    return 0;
}
void _afnd_ofus_dog_fobaz(_afnd_ofus_quux_hello
                              _afnd_ofus_fred_joe)
{
    {
        if (!(_afnd_ofus_fred_joe == NULL))
            goto _afnd_ofus_dog_foobaz;
        return;
    _afnd_ofus_dog_foobaz:;
    }
    free(_afnd_ofus_fred_joe);
}
int _afnd_ofus_dog_quux(FILE *fd, _afnd_ofus_quux_obscure *
                                      _afnd_ofus_fred_foobaz)
{
    int i;
    {
        i = 0;
    _afnd_ofus_dog_fred:
        if (!(i <
              _afnd_ofus_quux_bush(_afnd_ofus_fred_foobaz)))
            goto _afnd_ofus_dog_dog;
        goto _afnd_ofus_dog_cat;
    _afnd_ofus_dog_fish:
        i++;
        goto _afnd_ofus_dog_fred;
    _afnd_ofus_dog_cat:
    {
        fprintf(fd, "%d\n", _afnd_ofus_fred_foobaz->_afnd_ofus_quux_magic[i]);
    }
        goto _afnd_ofus_dog_fish;
    _afnd_ofus_dog_dog:;
    }
    return 0;
}
int _afnd_ofus_dog_gasp(FILE *fd, _afnd_ofus_quux_hello
                                      _afnd_ofus_fred_nasa)
{
    int i;
    {
        i = 0;
    _afnd_ofus_dog_bad:
        if (!(_afnd_ofus_fred_nasa[i] < 2))
            goto _afnd_ofus_dog_bug;
        goto _afnd_ofus_dog_silly;
    _afnd_ofus_dog_buggy:
        i++;
        goto _afnd_ofus_dog_bad;
    _afnd_ofus_dog_silly:
    {
        fprintf(fd, "%d\n",
                _afnd_ofus_fred_nasa[i]);
    }
        goto _afnd_ofus_dog_buggy;
    _afnd_ofus_dog_bug:;
    }
    return 0;
}
void _afnd_ofus_dog_mum(FILE *fd, _afnd_ofus_quux_hello _afnd_ofus_fred_joe, int _afnd_ofus_nasa)
{
    int i;
    {
        i = 0;
    _afnd_ofus_dog_dad:
        if (!(i <
              _afnd_ofus_nasa))
            goto _afnd_ofus_dog_disk;
        goto _afnd_ofus_dog_empty;
    _afnd_ofus_dog_full:
        i++;
        goto _afnd_ofus_dog_dad;
    _afnd_ofus_dog_empty:
    {
        fprintf(
            fd, "%d", _afnd_ofus_fred_joe[i]);
    }
        goto _afnd_ofus_dog_full;
    _afnd_ofus_dog_disk:;
    }
    fprintf(fd, "\n");
}
int _afnd_ofus_dog_fast(_afnd_ofus_quux_hello
                            _afnd_ofus_fred_joe,
                        int _afnd_ofus_nasa)
{
    int i;
    {
        i = 0;
    _afnd_ofus_dog_small:
        if (!(
                i < _afnd_ofus_nasa))
            goto _afnd_ofus_dog_big;
        goto _afnd_ofus_dog_ok;
    _afnd_ofus_dog_hello:
        i++;
        goto _afnd_ofus_dog_small;
    _afnd_ofus_dog_ok:
    {
        {
            if (!(
                    _afnd_ofus_fred_joe[i] != 0))
                goto _afnd_ofus_dog_bye;
            goto _afnd_ofus_dog_big;
        _afnd_ofus_dog_bye:;
        }
    }
        goto _afnd_ofus_dog_hello;
    _afnd_ofus_dog_big:;
    }
    return (i == _afnd_ofus_nasa);
}
struct _AFND
{
    char *nombre;
    _afnd_ofus_fbi *
        _afnd_ofus_dog_magic;
    int num_estados;
    int num_simbolos;
    _afnd_ofus_fast **
        _afnd_ofus_dog_obscure;
    int **_afnd_ofus_dog_speed;
    _afnd_ofus_bar_foobaz *
        _afnd_ofus_dog_index;
    _afnd_ofus_quux_hello **_afnd_ofus_dog_bill;
    _afnd_ofus_clinton *_afnd_ofus_dog_joe;
    _afnd_ofus_clinton *_afnd_ofus_dog_emacs;
    _afnd_ofus_quux_hello _afnd_ofus_dog_vi;
    _afnd_ofus_quux_hello *
        _afnd_ofus_dog_rms;
};
AFND *AFNDNuevo(char *nombre, int num_estados, int num_simbolos)
{
    AFND *p_afnd;
    int i;
    int j;
    p_afnd = (AFND *)malloc(sizeof(AFND));
    p_afnd->nombre = (char *)malloc(strlen(nombre) + 1);
    strcpy(p_afnd->nombre, nombre);
    p_afnd->_afnd_ofus_dog_magic = _afnd_ofus_cia("A", num_simbolos);
    p_afnd->num_estados = num_estados;
    p_afnd->num_simbolos = num_simbolos;
    p_afnd->_afnd_ofus_dog_obscure = (_afnd_ofus_fast **)malloc(sizeof(_afnd_ofus_fast *) *
                                                                num_estados);
    {
        i = 0;
    _afnd_ofus_dog_fbi:
        if (!(i < num_estados))
            goto _afnd_ofus_dog_cia;
        goto _afnd_ofus_dog_nasa;
    _afnd_ofus_dog_err:
        i++;
        goto _afnd_ofus_dog_fbi;
    _afnd_ofus_dog_nasa:
    {
        p_afnd->_afnd_ofus_dog_obscure[i] = NULL;
    }
        goto _afnd_ofus_dog_err;
    _afnd_ofus_dog_cia:;
    }
    p_afnd->_afnd_ofus_dog_speed = (int **)malloc(num_estados * sizeof(int *));
    {
        i = 0;
    _afnd_ofus_dog_google:
        if (!(i <
              num_estados))
            goto _afnd_ofus_dog_yahoo;
        goto _afnd_ofus_dog_trick;
    _afnd_ofus_dog_hint:
        i++;
        goto _afnd_ofus_dog_google;
    _afnd_ofus_dog_trick:
    {
        p_afnd->_afnd_ofus_dog_speed[i] = (int *)malloc(num_estados * sizeof(int));
    }
        goto _afnd_ofus_dog_hint;
    _afnd_ofus_dog_yahoo:;
    }
    {
        i = 0;
    _afnd_ofus_dog_black:
        if (!(i <
              num_estados))
            goto _afnd_ofus_dog_red;
        goto _afnd_ofus_dog_green;
    _afnd_ofus_dog_yellow:
        i++;
        goto _afnd_ofus_dog_black;
    _afnd_ofus_dog_green:
    {
        {
            j = 0;
        _afnd_ofus_dog_blue:
            if (!(j < num_estados))
                goto _afnd_ofus_dog_magenta;
            goto _afnd_ofus_dog_cyan;
        _afnd_ofus_dog_white:
            j++;
            goto _afnd_ofus_dog_blue;
        _afnd_ofus_dog_cyan:
        {
            p_afnd->_afnd_ofus_dog_speed[i][j] = 0;
        }
            goto _afnd_ofus_dog_white;
        _afnd_ofus_dog_magenta:;
        }
    }
        goto _afnd_ofus_dog_yellow;
    _afnd_ofus_dog_red:;
    }
    p_afnd->_afnd_ofus_dog_index = _afnd_ofus_bar_quux("RL",
                                                       num_estados);
    p_afnd->_afnd_ofus_dog_bill = (_afnd_ofus_quux_hello **)malloc(
        num_estados * sizeof(_afnd_ofus_quux_hello *));
    {
        i = 0;
    _afnd_ofus_dog_clinton:
        if (!(i < num_estados))
            goto _afnd_ofus_dog_bush;
        goto _afnd_ofus_dog_jfk;
    _afnd_ofus_dog_sex:
        i++;
        goto _afnd_ofus_dog_clinton;
    _afnd_ofus_dog_jfk:
    {
        p_afnd
            ->_afnd_ofus_dog_bill[i] = (_afnd_ofus_quux_hello *)malloc(num_simbolos * sizeof(
                                                                                          _afnd_ofus_quux_hello));
    }
        goto _afnd_ofus_dog_sex;
    _afnd_ofus_dog_bush:;
    }
    {
        i = 0;
    _afnd_ofus_cat_foo:
        if (!(i < num_estados))
            goto _afnd_ofus_cat_bar;
        goto _afnd_ofus_cat_baz;
    _afnd_ofus_cat_fobar:
        i++;
        goto _afnd_ofus_cat_foo;
    _afnd_ofus_cat_baz:
    {
        {
            j = 0;
        _afnd_ofus_cat_foobar:
            if (!(j < num_simbolos))
                goto _afnd_ofus_cat_fobaz;
            goto _afnd_ofus_cat_foobaz;
        _afnd_ofus_cat_quux:
            j++;
            goto _afnd_ofus_cat_foobar;
        _afnd_ofus_cat_foobaz:
        {
            p_afnd->_afnd_ofus_dog_bill[i][j] = _afnd_ofus_fred_bill(num_estados);
        }
            goto _afnd_ofus_cat_quux;
        _afnd_ofus_cat_fobaz:;
        }
    }
        goto _afnd_ofus_cat_fobar;
    _afnd_ofus_cat_bar:;
    }
    p_afnd
        ->_afnd_ofus_dog_joe = _afnd_ofus_bush();
    p_afnd->_afnd_ofus_dog_emacs = NULL;
    p_afnd->_afnd_ofus_dog_vi = _afnd_ofus_fred_bill(num_estados);
    p_afnd->_afnd_ofus_dog_rms = NULL;
    return p_afnd;
}
void AFNDImprime(FILE *fd, AFND *p_afnd)
{
    int i, j, _afnd_ofus_foobaz_cyan;
    {
        if (!(p_afnd == NULL))
            goto _afnd_ofus_cat_fred;
        return;
    _afnd_ofus_cat_fred:;
    }
    {
        if (!(p_afnd->nombre != NULL))
            goto _afnd_ofus_cat_dog;
        {
            fprintf(fd, "%s=", p_afnd->nombre);
        }
    _afnd_ofus_cat_dog:;
    }
    fprintf(fd, "{");
    fprintf(fd, "\n\tnum_simbolos = %d\n", p_afnd->num_simbolos);
    {
        if (!(p_afnd->_afnd_ofus_dog_magic != NULL))
            goto _afnd_ofus_cat_cat;
        {
            fprintf(fd,
                    "\n\t");
            _afnd_ofus_trick(fd, p_afnd->_afnd_ofus_dog_magic);
        }
    _afnd_ofus_cat_cat:;
    }
    fprintf(fd, "\n\tnum_estados = %d\n", p_afnd->num_estados);
    {
        if (!(p_afnd->_afnd_ofus_dog_obscure != NULL))
            goto _afnd_ofus_cat_fish;
        {
            fprintf(fd, "\n\tQ={");
            {
                i = 0;
            _afnd_ofus_cat_gasp:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_cat_bad;
                goto _afnd_ofus_cat_bug;
            _afnd_ofus_cat_silly:
                i++;
                goto _afnd_ofus_cat_gasp;
            _afnd_ofus_cat_bug:
            {
                {
                    if (!(p_afnd->_afnd_ofus_dog_obscure[i] != NULL))
                        goto _afnd_ofus_cat_buggy;
                    _afnd_ofus_hello(fd, p_afnd->_afnd_ofus_dog_obscure[i]);
                _afnd_ofus_cat_buggy:;
                }
                fprintf(fd, " ");
            }
                goto _afnd_ofus_cat_silly;
            _afnd_ofus_cat_bad:;
            }
            fprintf(fd, "}\n");
        }
    _afnd_ofus_cat_fish:;
    }
    fprintf(fd,
            "\n\t");
    _afnd_ofus_bar_dog(fd, p_afnd->_afnd_ofus_dog_index);
    {
        if (!(p_afnd->_afnd_ofus_dog_bill != NULL))
            goto _afnd_ofus_cat_mum;
        {
            fprintf(fd, "\n");
            fprintf(
                fd, "\tFuncion de Transición = {\n");
            {
                i = 0;
            _afnd_ofus_cat_dad:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_cat_disk;
                goto _afnd_ofus_cat_empty;
            _afnd_ofus_cat_full:
                i++;
                goto _afnd_ofus_cat_dad;
            _afnd_ofus_cat_empty:
            {
                {
                    j = 0;
                _afnd_ofus_cat_fast:
                    if (!(j < p_afnd->num_simbolos))
                        goto _afnd_ofus_cat_small;
                    goto _afnd_ofus_cat_big;
                _afnd_ofus_cat_ok:
                    j++;
                    goto _afnd_ofus_cat_fast;
                _afnd_ofus_cat_big:
                {
                    fprintf(fd, "\t\tf(%s,%s)={ ", AFNDNombreEstadoEn(p_afnd, i),
                            AFNDSimboloEn(p_afnd, j));
                    {
                        _afnd_ofus_foobaz_cyan = 0;
                    _afnd_ofus_cat_hello:
                        if (!(
                                _afnd_ofus_foobaz_cyan < p_afnd->num_estados))
                            goto _afnd_ofus_cat_bye;
                        goto _afnd_ofus_cat_magic;
                    _afnd_ofus_cat_obscure:
                        _afnd_ofus_foobaz_cyan++;
                        goto _afnd_ofus_cat_hello;
                    _afnd_ofus_cat_magic:
                    {
                        {
                            if (!((p_afnd->_afnd_ofus_dog_bill[i][j])[_afnd_ofus_foobaz_cyan] == 1))
                                goto _afnd_ofus_cat_speed;
                            fprintf(fd, "%s ",
                                    AFNDNombreEstadoEn(p_afnd, _afnd_ofus_foobaz_cyan));
                        _afnd_ofus_cat_speed:;
                        }
                    }
                        goto _afnd_ofus_cat_obscure;
                    _afnd_ofus_cat_bye:;
                    }
                    fprintf(fd, "}\n");
                }
                    goto _afnd_ofus_cat_ok;
                _afnd_ofus_cat_small:;
                }
            }
                goto _afnd_ofus_cat_full;
            _afnd_ofus_cat_disk:;
            }
            fprintf(fd, "\t}\n");
        }
    _afnd_ofus_cat_mum:;
    }
    fprintf(fd,
            "}\n");
}
int _afnd_ofus_cat_index(AFND *p_afnd, char *nombre)
{
    int i;
    {
        i = 0;
    _afnd_ofus_cat_bill:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_cat_joe;
        goto _afnd_ofus_cat_emacs;
    _afnd_ofus_cat_vi:
        i++;
        goto _afnd_ofus_cat_bill;
    _afnd_ofus_cat_emacs:
    {
        {
            if (!(p_afnd->_afnd_ofus_dog_obscure[i] != NULL))
                goto _afnd_ofus_cat_rms;
            {
                {
                    if (!(strcmp(_afnd_ofus_magic(p_afnd->_afnd_ofus_dog_obscure[i]), nombre) == 0))
                        goto _afnd_ofus_cat_fbi;
                    {
                        return 1;
                    }
                _afnd_ofus_cat_fbi:;
                }
            }
        _afnd_ofus_cat_rms:;
        }
    }
        goto _afnd_ofus_cat_vi;
    _afnd_ofus_cat_joe:;
    }
    return 0;
}
char *AFNDNombreEstadoEn(AFND *p_afnd, int pos)
{
    {
        if (!(pos < p_afnd->num_estados))
            goto _afnd_ofus_cat_cia;
        return _afnd_ofus_magic(
            p_afnd->_afnd_ofus_dog_obscure[pos]);
        goto _afnd_ofus_cat_nasa;
    _afnd_ofus_cat_cia:;
        return NULL;
    _afnd_ofus_cat_nasa:;
    }
}
char *AFNDSimboloEn(AFND
                        *p_afnd,
                    int pos)
{
    {
        if (!(pos < p_afnd->num_simbolos))
            goto _afnd_ofus_cat_err;
        return _afnd_ofus_black(p_afnd->_afnd_ofus_dog_magic, pos);
        goto _afnd_ofus_cat_google;
    _afnd_ofus_cat_err:;
        return NULL;
    _afnd_ofus_cat_google:;
    }
}
void AFNDElimina(AFND *p_afnd)
{
    int i, j;
    {
        if (!(p_afnd == NULL))
            goto _afnd_ofus_cat_yahoo;
        return;
    _afnd_ofus_cat_yahoo:;
    }
    {
        if (!(p_afnd->nombre != NULL))
            goto _afnd_ofus_cat_trick;
        {
            free(p_afnd->nombre);
            p_afnd->nombre = NULL;
        }
    _afnd_ofus_cat_trick:;
    }
    {
        if (!(p_afnd->_afnd_ofus_dog_magic != NULL))
            goto _afnd_ofus_cat_hint;
        {
            _afnd_ofus_err(p_afnd->_afnd_ofus_dog_magic);
            p_afnd->_afnd_ofus_dog_magic = NULL;
        }
    _afnd_ofus_cat_hint:;
    }
    {
        if (!(p_afnd->_afnd_ofus_dog_obscure != NULL))
            goto _afnd_ofus_cat_black;
        {
            {
                i = 0;
            _afnd_ofus_cat_red:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_cat_green;
                goto _afnd_ofus_cat_yellow;
            _afnd_ofus_cat_blue:
                i++;
                goto _afnd_ofus_cat_red;
            _afnd_ofus_cat_yellow:
            {
                _afnd_ofus_big(p_afnd->_afnd_ofus_dog_obscure[i]);
            }
                goto _afnd_ofus_cat_blue;
            _afnd_ofus_cat_green:;
            }
            free(p_afnd->_afnd_ofus_dog_obscure);
            p_afnd->_afnd_ofus_dog_obscure = NULL;
        }
    _afnd_ofus_cat_black:;
    }
    {
        if (!(p_afnd->_afnd_ofus_dog_speed != NULL))
            goto _afnd_ofus_cat_magenta;
        {
            {
                i = 0;
            _afnd_ofus_cat_cyan:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_cat_white;
                goto _afnd_ofus_cat_clinton;
            _afnd_ofus_cat_bush:
                i++;
                goto _afnd_ofus_cat_cyan;
            _afnd_ofus_cat_clinton:
            {
                free(p_afnd->_afnd_ofus_dog_speed[i]);
            }
                goto _afnd_ofus_cat_bush;
            _afnd_ofus_cat_white:;
            }
        }
    _afnd_ofus_cat_magenta:;
    }
    free(p_afnd->_afnd_ofus_dog_speed);
    {
        if (!(p_afnd->_afnd_ofus_dog_index != NULL))
            goto _afnd_ofus_cat_jfk;
        _afnd_ofus_bar_fish(p_afnd
                                ->_afnd_ofus_dog_index);
    _afnd_ofus_cat_jfk:;
    }
    {
        if (!(p_afnd->_afnd_ofus_dog_bill != NULL))
            goto _afnd_ofus_cat_sex;
        {
            {
                i = 0;
            _afnd_ofus_fish_foo:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_fish_bar;
                goto _afnd_ofus_fish_baz;
            _afnd_ofus_fish_fobar:
                i++;
                goto _afnd_ofus_fish_foo;
            _afnd_ofus_fish_baz:
            {
                {
                    j = 0;
                _afnd_ofus_fish_foobar:
                    if (!(j < p_afnd->num_simbolos))
                        goto _afnd_ofus_fish_fobaz;
                    goto _afnd_ofus_fish_foobaz;
                _afnd_ofus_fish_quux:
                    j++;
                    goto _afnd_ofus_fish_foobar;
                _afnd_ofus_fish_foobaz:
                {
                    _afnd_ofus_dog_fobaz(p_afnd->_afnd_ofus_dog_bill[i][j]);
                }
                    goto _afnd_ofus_fish_quux;
                _afnd_ofus_fish_fobaz:;
                }
                free(p_afnd->_afnd_ofus_dog_bill[i]);
            }
                goto _afnd_ofus_fish_fobar;
            _afnd_ofus_fish_bar:;
            }
        }
    _afnd_ofus_cat_sex:;
    }
    free(p_afnd->_afnd_ofus_dog_bill);
    {
        if (!(p_afnd->_afnd_ofus_dog_joe != NULL))
            goto _afnd_ofus_fish_fred;
        {
            _afnd_ofus_jfk(p_afnd->_afnd_ofus_dog_joe);
        }
    _afnd_ofus_fish_fred:;
    }
    {
        if (!(
                p_afnd->_afnd_ofus_dog_vi != NULL))
            goto _afnd_ofus_fish_dog;
        {
            _afnd_ofus_dog_fobaz(p_afnd->_afnd_ofus_dog_vi);
        }
    _afnd_ofus_fish_dog:;
    }
    free(
        p_afnd);
}
int AFNDIndiceDeSimbolo(AFND *p_afnd, char *nombre) { return _afnd_ofus_red(p_afnd->_afnd_ofus_dog_magic, nombre); }
int AFNDIndiceDeEstado(
    AFND *p_afnd, char *nombre)
{
    int i;
    {
        i = 0;
    _afnd_ofus_fish_cat:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_fish_fish;
        goto _afnd_ofus_fish_gasp;
    _afnd_ofus_fish_bad:
        i++;
        goto _afnd_ofus_fish_cat;
    _afnd_ofus_fish_gasp:
    {
        {
            if (!(
                    _afnd_ofus_bye(p_afnd->_afnd_ofus_dog_obscure[i], nombre)))
                goto _afnd_ofus_fish_bug;
            return i;
        _afnd_ofus_fish_bug:;
        }
    }
        goto _afnd_ofus_fish_bad;
    _afnd_ofus_fish_fish:;
    }
    return -1;
}
_afnd_ofus_quux_hello _afnd_ofus_fish_silly(
    AFND *p_afnd, char *_afnd_ofus_fish_buggy, char *_afnd_ofus_fish_mum) { return p_afnd
                                                                                ->_afnd_ofus_dog_bill[AFNDIndiceDeEstado(p_afnd, _afnd_ofus_fish_buggy)][AFNDIndiceDeSimbolo(p_afnd, _afnd_ofus_fish_mum)]; }
_afnd_ofus_quux_hello
_afnd_ofus_fish_dad(AFND *p_afnd, int _afnd_ofus_fish_disk, int _afnd_ofus_fish_empty) { return p_afnd->_afnd_ofus_dog_bill[_afnd_ofus_fish_disk][_afnd_ofus_fish_empty]; }
AFND *AFNDInsertaSimbolo(AFND *p_afnd, char *simbolo)
{
    _afnd_ofus_yahoo(p_afnd->_afnd_ofus_dog_magic, simbolo);
    return p_afnd;
}
AFND *
AFNDInsertaEstado(AFND *p_afnd, char *nombre, int tipo)
{
    int i;
    {
        i = 0;
    _afnd_ofus_fish_full:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_fish_fast;
        goto _afnd_ofus_fish_small;
    _afnd_ofus_fish_big:
        i++;
        goto _afnd_ofus_fish_full;
    _afnd_ofus_fish_small:
    {
        {
            if (!(p_afnd->_afnd_ofus_dog_obscure[i] == NULL))
                goto _afnd_ofus_fish_ok;
            {
                p_afnd->_afnd_ofus_dog_obscure[i] = _afnd_ofus_small(nombre,
                                                                     tipo);
                goto _afnd_ofus_fish_fast;
            }
        _afnd_ofus_fish_ok:;
        }
    }
        goto _afnd_ofus_fish_big;
    _afnd_ofus_fish_fast:;
    }
    {
        if (!((tipo == INICIAL) || (tipo ==
                                    INICIAL_Y_FINAL)))
            goto _afnd_ofus_fish_hello;
        {
            p_afnd->_afnd_ofus_dog_vi[i] = 1;
        }
    _afnd_ofus_fish_hello:;
    }
    return p_afnd;
}
AFND *AFNDInsertaLTransicion(AFND *p_afnd, char *nombre_estado_i, char *nombre_estado_f)
{
    int _afnd_ofus_fish_bye,
        _afnd_ofus_fish_magic;
    _afnd_ofus_fish_bye = AFNDIndiceDeEstado(p_afnd,
                                             nombre_estado_i);
    _afnd_ofus_fish_magic = AFNDIndiceDeEstado(p_afnd,
                                               nombre_estado_f);
    _afnd_ofus_bar_bug(p_afnd->_afnd_ofus_dog_index,
                       _afnd_ofus_fish_bye, _afnd_ofus_fish_magic);
    return p_afnd;
}
AFND *
AFNDInsertaTransicion(AFND *p_afnd, char *nombre_estado_i, char *nombre_simbolo_entrada, char *nombre_estado_f)
{
    int _afnd_ofus_fish_bye,
        _afnd_ofus_fish_magic, _afnd_ofus_fish_obscure;
    _afnd_ofus_fish_bye =
        AFNDIndiceDeEstado(p_afnd, nombre_estado_i);
    _afnd_ofus_fish_magic =
        AFNDIndiceDeEstado(p_afnd, nombre_estado_f);
    _afnd_ofus_fish_obscure =
        AFNDIndiceDeSimbolo(p_afnd, nombre_simbolo_entrada);
    (p_afnd->_afnd_ofus_dog_bill[_afnd_ofus_fish_bye][_afnd_ofus_fish_obscure])[_afnd_ofus_fish_magic] = 1;
    return p_afnd;
}
AFND *AFNDInsertaLetra(AFND *p_afnd, char
                                         *letra)
{
    _afnd_ofus_bar_bar(p_afnd->_afnd_ofus_dog_joe, letra);
    return p_afnd;
}
void AFNDImprimeConjuntoEstadosActual(FILE *fd, AFND *p_afnd)
{
    int i;
    {
        if (!(p_afnd
                  ->_afnd_ofus_dog_vi != NULL))
            goto _afnd_ofus_fish_speed;
        {
            fprintf(fd,
                    "\nACTUALMENTE EN {");
            {
                i = 0;
            _afnd_ofus_fish_index:
                if (!(i < p_afnd->num_estados))
                    goto _afnd_ofus_fish_bill;
                goto _afnd_ofus_fish_joe;
            _afnd_ofus_fish_emacs:
                i++;
                goto _afnd_ofus_fish_index;
            _afnd_ofus_fish_joe:
            {
                {
                    if (!(p_afnd->_afnd_ofus_dog_vi[i] == 1))
                        goto _afnd_ofus_fish_vi;
                    {
                        _afnd_ofus_hello(fd, p_afnd->_afnd_ofus_dog_obscure[i]);
                    }
                _afnd_ofus_fish_vi:;
                }
            }
                goto _afnd_ofus_fish_emacs;
            _afnd_ofus_fish_bill:;
            }
            fprintf(fd, "}\n");
        }
    _afnd_ofus_fish_speed:;
    }
}
void AFNDImprimeCadenaActual(FILE *fd, AFND *p_afnd) { _afnd_ofus_bar_foo(fd, p_afnd->_afnd_ofus_dog_joe); }
void AFNDTransita(AFND *p_afnd)
{
    char *_afnd_ofus_fish_rms;
    int _afnd_ofus_fish_fbi;
    int i;
    int j;
    int _afnd_ofus_foobaz_cyan;
    _afnd_ofus_quux_hello _afnd_ofus_fish_cia;
    _afnd_ofus_quux_hello
        _afnd_ofus_fish_nasa;
    {
        if (!(p_afnd == NULL))
            goto _afnd_ofus_fish_err;
        return;
    _afnd_ofus_fish_err:;
    }
    {
        if (!(_afnd_ofus_bar_fobar(p_afnd->_afnd_ofus_dog_joe) ==
              0))
            goto _afnd_ofus_fish_google;
        return;
    _afnd_ofus_fish_google:;
    }
    _afnd_ofus_fish_nasa = _afnd_ofus_fred_bill(p_afnd->num_estados);
    _afnd_ofus_fish_rms = _afnd_ofus_bar_baz(p_afnd->_afnd_ofus_dog_joe);
    _afnd_ofus_fish_fbi = AFNDIndiceDeSimbolo(p_afnd, _afnd_ofus_fish_rms);
    {
        i = 0;
    _afnd_ofus_fish_yahoo:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_fish_trick;
        goto _afnd_ofus_fish_hint;
    _afnd_ofus_fish_black:
        i++;
        goto _afnd_ofus_fish_yahoo;
    _afnd_ofus_fish_hint:
    {
        {
            if (!(p_afnd->_afnd_ofus_dog_vi[i] == 1))
                goto _afnd_ofus_fish_red;
            {
                _afnd_ofus_fish_cia = _afnd_ofus_fish_dad(p_afnd, i,
                                                          _afnd_ofus_fish_fbi);
                {
                    j = 0;
                _afnd_ofus_fish_green:
                    if (!(j < p_afnd->num_estados))
                        goto _afnd_ofus_fish_yellow;
                    goto _afnd_ofus_fish_blue;
                _afnd_ofus_fish_magenta:
                    j++;
                    goto _afnd_ofus_fish_green;
                _afnd_ofus_fish_blue:
                {
                    {
                        if (!(_afnd_ofus_fish_cia
                                  [j] == 1))
                            goto _afnd_ofus_fish_cyan;
                        {
                            _afnd_ofus_fish_nasa[j] = 1;
                            {
                                _afnd_ofus_foobaz_cyan = 0;
                            _afnd_ofus_fish_white:
                                if (!(_afnd_ofus_foobaz_cyan <
                                      p_afnd->num_estados))
                                    goto _afnd_ofus_fish_clinton;
                                goto _afnd_ofus_fish_bush;
                            _afnd_ofus_fish_jfk:
                                _afnd_ofus_foobaz_cyan++;
                                goto _afnd_ofus_fish_white;
                            _afnd_ofus_fish_bush:
                            {
                                {
                                    if (!(AFNDCierreLTransicionIJ(p_afnd, j,
                                                                  _afnd_ofus_foobaz_cyan)))
                                        goto _afnd_ofus_fish_sex;
                                    {
                                        _afnd_ofus_fish_nasa[_afnd_ofus_foobaz_cyan] = 1;
                                    }
                                _afnd_ofus_fish_sex:;
                                }
                            }
                                goto _afnd_ofus_fish_jfk;
                            _afnd_ofus_fish_clinton:;
                            }
                        }
                    _afnd_ofus_fish_cyan:;
                    }
                }
                    goto _afnd_ofus_fish_magenta;
                _afnd_ofus_fish_yellow:;
                }
            }
        _afnd_ofus_fish_red:;
        }
    }
        goto _afnd_ofus_fish_black;
    _afnd_ofus_fish_trick:;
    }
    {
        i = 0;
    _afnd_ofus_gasp_foo:
        if (!(i <
              p_afnd->num_estados))
            goto _afnd_ofus_gasp_bar;
        goto _afnd_ofus_gasp_baz;
    _afnd_ofus_gasp_fobar:
        i++;
        goto _afnd_ofus_gasp_foo;
    _afnd_ofus_gasp_baz:
    {
    }
        goto _afnd_ofus_gasp_fobar;
    _afnd_ofus_gasp_bar:;
    }
    _afnd_ofus_dog_fobaz(p_afnd->_afnd_ofus_dog_vi);
    p_afnd->_afnd_ofus_dog_vi = _afnd_ofus_fish_nasa;
    free(
        _afnd_ofus_fish_rms);
}
int _afnd_ofus_gasp_foobar(const char *_afnd_ofus_fish,
                           const char *_afnd_ofus_gasp)
{
    fprintf(stdout, "ESTADO 1: %s\n", (char *)_afnd_ofus_fish);
    fprintf(stdout, "ESTADO 2: %s\n", _afnd_ofus_gasp);
    return strcmp((char *)_afnd_ofus_fish, (char *)_afnd_ofus_gasp);
}
void _afnd_ofus_gasp_fobaz(char **_afnd_ofus_ok, int _afnd_ofus_gasp_foobaz)
{
    int i;
    {
        if (!(_afnd_ofus_ok == NULL))
            goto _afnd_ofus_gasp_quux;
        return;
        goto _afnd_ofus_gasp_fred;
    _afnd_ofus_gasp_quux:;
        {
            {
                i = 0;
            _afnd_ofus_gasp_dog:
                if (!(i <
                      _afnd_ofus_gasp_foobaz))
                    goto _afnd_ofus_gasp_cat;
                goto _afnd_ofus_gasp_fish;
            _afnd_ofus_gasp_gasp:
                i++;
                goto _afnd_ofus_gasp_dog;
            _afnd_ofus_gasp_fish:
            {
                free(
                    _afnd_ofus_ok[i]);
            }
                goto _afnd_ofus_gasp_gasp;
            _afnd_ofus_gasp_cat:;
            }
        }
    _afnd_ofus_gasp_fred:;
    }
    free(_afnd_ofus_ok);
    return;
}
void AFNDProcesaEntrada(
    FILE *fd, AFND *p_afnd)
{
    AFNDImprimeConjuntoEstadosActual(fd, p_afnd);
    AFNDImprimeCadenaActual(fd, p_afnd);
    {
    _afnd_ofus_gasp_bad:
        if (!((
                  _afnd_ofus_bar_fobar(p_afnd->_afnd_ofus_dog_joe) > 0) &&
              !_afnd_ofus_dog_fast(
                  p_afnd->_afnd_ofus_dog_vi, p_afnd->num_estados)))
            goto _afnd_ofus_gasp_bug;
        {
            AFNDTransita(p_afnd);
            AFNDImprimeConjuntoEstadosActual(fd, p_afnd);
            AFNDImprimeCadenaActual(fd, p_afnd);
        }
        goto _afnd_ofus_gasp_bad;
    _afnd_ofus_gasp_bug:;
    }
}
int AFNDIndiceEstadoInicial(AFND *p_afnd)
{
    int i;
    {
        i = 0;
    _afnd_ofus_gasp_silly:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_gasp_buggy;
        goto _afnd_ofus_gasp_mum;
    _afnd_ofus_gasp_dad:
        i++;
        goto _afnd_ofus_gasp_silly;
    _afnd_ofus_gasp_mum:
    {
        {
            if (!((_afnd_ofus_obscure(p_afnd->_afnd_ofus_dog_obscure[i]) == INICIAL) || (_afnd_ofus_obscure(p_afnd->_afnd_ofus_dog_obscure[i]) ==
                                                                                         INICIAL_Y_FINAL)))
                goto _afnd_ofus_gasp_disk;
            return i;
        _afnd_ofus_gasp_disk:;
        }
    }
        goto _afnd_ofus_gasp_dad;
    _afnd_ofus_gasp_buggy:;
    }
    return -1;
}
AFND *
AFNDInicializaCadenaActual(AFND *p_afnd)
{
    {
        if (!(p_afnd != NULL))
            goto _afnd_ofus_gasp_empty;
        {
            _afnd_ofus_jfk(p_afnd->_afnd_ofus_dog_joe);
            p_afnd->_afnd_ofus_dog_joe = _afnd_ofus_bush();
        }
    _afnd_ofus_gasp_empty:;
    }
    return p_afnd;
}
AFND *AFNDInicializaEstado(AFND *p_afnd)
{
    int _afnd_ofus_gasp_full;
    int i;
    _afnd_ofus_gasp_full = AFNDIndiceEstadoInicial(p_afnd);
    {
        i = 0;
    _afnd_ofus_gasp_fast
        :
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_gasp_small;
        goto _afnd_ofus_gasp_big;
    _afnd_ofus_gasp_ok:
        i++;
        goto _afnd_ofus_gasp_fast;
    _afnd_ofus_gasp_big:
    {
        {
            if (!(i == _afnd_ofus_gasp_full))
                goto _afnd_ofus_gasp_hello;
            p_afnd->_afnd_ofus_dog_vi[i] = 1;
            goto _afnd_ofus_gasp_bye;
        _afnd_ofus_gasp_hello
            :;
            p_afnd->_afnd_ofus_dog_vi[i] = 0;
        _afnd_ofus_gasp_bye:;
        }
    }
        goto _afnd_ofus_gasp_ok;
    _afnd_ofus_gasp_small:;
    }
    {
        i = 0;
    _afnd_ofus_gasp_magic:
        if (!(i <
              p_afnd->num_estados))
            goto _afnd_ofus_gasp_obscure;
        goto _afnd_ofus_gasp_speed;
    _afnd_ofus_gasp_index:
        i++;
        goto _afnd_ofus_gasp_magic;
    _afnd_ofus_gasp_speed:
    {
        {
            if (!(AFNDCierreLTransicionIJ(p_afnd, _afnd_ofus_gasp_full, i)))
                goto _afnd_ofus_gasp_bill;
            p_afnd->_afnd_ofus_dog_vi[i] = 1;
        _afnd_ofus_gasp_bill:;
        }
    }
        goto _afnd_ofus_gasp_index;
    _afnd_ofus_gasp_obscure:;
    }
    return p_afnd;
}
AFND *
AFNDCierraLTransicion(AFND *p_afnd)
{
    {
        if (!(p_afnd != NULL))
            goto _afnd_ofus_gasp_joe;
        {
            _afnd_ofus_bar_mum(_afnd_ofus_bar_dad(p_afnd->_afnd_ofus_dog_index));
        }
    _afnd_ofus_gasp_joe:;
    }
    return p_afnd;
}
int AFNDLTransicionIJ(AFND *p_afnd, int i, int j) { return _afnd_ofus_bar_disk(p_afnd->_afnd_ofus_dog_index, i, j); }
int AFNDIndicePrimerEstadoFinal(AFND *p_afnd)
{
    int i =
        0;
    {
        i = 0;
    _afnd_ofus_gasp_emacs:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_gasp_vi;
        goto _afnd_ofus_gasp_rms;
    _afnd_ofus_gasp_fbi:
        i++;
        goto _afnd_ofus_gasp_emacs;
    _afnd_ofus_gasp_rms:
    {
        {
            if (!((_afnd_ofus_obscure(
                       _afnd_ofus_quux_ok(p_afnd, i)) == FINAL) ||
                  (_afnd_ofus_obscure(_afnd_ofus_quux_ok(
                       p_afnd, i)) == INICIAL_Y_FINAL)))
                goto _afnd_ofus_gasp_cia;
            goto _afnd_ofus_gasp_vi;
        _afnd_ofus_gasp_cia:;
        }
    }
        goto _afnd_ofus_gasp_fbi;
    _afnd_ofus_gasp_vi:;
    }
    return i;
}
AFND *_afnd_ofus_gasp_nasa(AFND *_afnd_ofus_gasp_err, AFND *_afnd_ofus_gasp_google, char *_afnd_ofus_gasp_yahoo, int _afnd_ofus_gasp_trick)
{
    int i, j, _afnd_ofus_foobaz_cyan;
    _afnd_ofus_fast *_afnd_ofus_gasp_hint;
    int tipo;
    char *_afnd_ofus_fobar_vi;
    {
        i = 0;
    _afnd_ofus_gasp_black:
        if (!(i <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_gasp_red;
        goto _afnd_ofus_gasp_green;
    _afnd_ofus_gasp_yellow:
        i++;
        goto _afnd_ofus_gasp_black;
    _afnd_ofus_gasp_green:
    {
        _afnd_ofus_gasp_hint = _afnd_ofus_quux_ok(
            _afnd_ofus_gasp_google, i);
        {
            if (!(_afnd_ofus_obscure(_afnd_ofus_gasp_hint) ==
                  FINAL))
                goto _afnd_ofus_gasp_blue;
            tipo = NORMAL;
            goto _afnd_ofus_gasp_magenta;
        _afnd_ofus_gasp_blue:;
            {
                if (!(_afnd_ofus_obscure(_afnd_ofus_gasp_hint) ==
                      INICIAL_Y_FINAL))
                    goto _afnd_ofus_gasp_cyan;
                tipo = NORMAL;
                goto _afnd_ofus_gasp_white;
            _afnd_ofus_gasp_cyan:;
                {
                    if (!(_afnd_ofus_obscure(
                              _afnd_ofus_gasp_hint) == INICIAL))
                        goto _afnd_ofus_gasp_clinton;
                    tipo = NORMAL;
                    goto _afnd_ofus_gasp_bush;
                _afnd_ofus_gasp_clinton:;
                    tipo = _afnd_ofus_obscure(
                        _afnd_ofus_gasp_hint);
                _afnd_ofus_gasp_bush:;
                }
            _afnd_ofus_gasp_white:;
            }
        _afnd_ofus_gasp_magenta:;
        }
        _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * (strlen(_afnd_ofus_gasp_yahoo) + strlen(_afnd_ofus_magic(_afnd_ofus_gasp_hint)) + 1));
        strcpy(_afnd_ofus_fobar_vi, _afnd_ofus_gasp_yahoo);
        strcat(
            _afnd_ofus_fobar_vi, _afnd_ofus_magic(_afnd_ofus_gasp_hint));
        AFNDInsertaEstado(
            _afnd_ofus_gasp_err, _afnd_ofus_fobar_vi, tipo);
        free(_afnd_ofus_fobar_vi);
    }
        goto _afnd_ofus_gasp_yellow;
    _afnd_ofus_gasp_red:;
    }
    {
        i = 0;
    _afnd_ofus_gasp_jfk:
        if (!(i <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_gasp_sex;
        goto _afnd_ofus_bad_foo;
    _afnd_ofus_bad_bar:
        i++;
        goto _afnd_ofus_gasp_jfk;
    _afnd_ofus_bad_foo:
    {
        j = 0;
    _afnd_ofus_bad_baz:
        if (!(j < _afnd_ofus_gasp_google->num_simbolos))
            goto _afnd_ofus_bad_fobar;
        goto _afnd_ofus_bad_foobar;
    _afnd_ofus_bad_fobaz:
        j++;
        goto _afnd_ofus_bad_baz;
    _afnd_ofus_bad_foobar:
    {
        _afnd_ofus_foobaz_cyan = 0;
    _afnd_ofus_bad_foobaz:
        if (!(_afnd_ofus_foobaz_cyan <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bad_quux;
        goto _afnd_ofus_bad_fred;
    _afnd_ofus_bad_dog:
        _afnd_ofus_foobaz_cyan++;
        goto _afnd_ofus_bad_foobaz;
    _afnd_ofus_bad_fred:
    {
        {
            if (!(
                    AFNDTransicionIndicesEstadoiSimboloEstadof(_afnd_ofus_gasp_google, i, j,
                                                               _afnd_ofus_foobaz_cyan) == 1))
                goto _afnd_ofus_bad_cat;
            {
                AFNDInsertaTransicion(
                    _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i + _afnd_ofus_gasp_trick), AFNDSimboloEn(_afnd_ofus_gasp_google, j),
                    AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_foobaz_cyan +
                                                                _afnd_ofus_gasp_trick));
            }
        _afnd_ofus_bad_cat:;
        }
    }
        goto _afnd_ofus_bad_dog;
    _afnd_ofus_bad_quux:;
    }
        goto _afnd_ofus_bad_fobaz;
    _afnd_ofus_bad_fobar:;
    }
        goto _afnd_ofus_bad_bar;
    _afnd_ofus_gasp_sex:;
    }
    {
        i = 0;
    _afnd_ofus_bad_fish:
        if (!(i <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bad_gasp;
        goto _afnd_ofus_bad_bad;
    _afnd_ofus_bad_bug:
        i++;
        goto _afnd_ofus_bad_fish;
    _afnd_ofus_bad_bad:
    {
        j = 0;
    _afnd_ofus_bad_silly:
        if (!(j < _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bad_buggy;
        goto _afnd_ofus_bad_mum;
    _afnd_ofus_bad_dad:
        j++;
        goto _afnd_ofus_bad_silly;
    _afnd_ofus_bad_mum:
    {
        {
            if (!(
                    AFNDLTransicionIJ(_afnd_ofus_gasp_google, i, j) == 1))
                goto _afnd_ofus_bad_disk;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i + _afnd_ofus_gasp_trick), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j + _afnd_ofus_gasp_trick));
            }
        _afnd_ofus_bad_disk:;
        }
    }
        goto _afnd_ofus_bad_dad;
    _afnd_ofus_bad_buggy:;
    }
        goto _afnd_ofus_bad_bug;
    _afnd_ofus_bad_gasp:;
    }
    return _afnd_ofus_gasp_err;
}
AFND *_afnd_ofus_bad_empty(
    AFND *_afnd_ofus_gasp_err, AFND *_afnd_ofus_gasp_google)
{
    int i;
    {
        i = 0;
    _afnd_ofus_bad_full:
        if (!(i < _afnd_ofus_gasp_google->num_simbolos))
            goto _afnd_ofus_bad_fast;
        goto _afnd_ofus_bad_small;
    _afnd_ofus_bad_big:
        i++;
        goto _afnd_ofus_bad_full;
    _afnd_ofus_bad_small:
    {
        AFNDInsertaSimbolo(
            _afnd_ofus_gasp_err, AFNDSimboloEn(_afnd_ofus_gasp_google, i));
    }
        goto _afnd_ofus_bad_big;
    _afnd_ofus_bad_fast:;
    }
    return _afnd_ofus_gasp_err;
}
AFND *
_afnd_ofus_bad_ok(AFND *_afnd_ofus_gasp_err, AFND *_afnd_ofus_gasp_google, char *_afnd_ofus_bad_hello, char *_afnd_ofus_bad_bye, int _afnd_ofus_gasp_trick)
{
    int j;
    {
        j = 0;
    _afnd_ofus_bad_magic:
        if (!(j < _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bad_obscure;
        goto _afnd_ofus_bad_speed;
    _afnd_ofus_bad_index:
        j++;
        goto _afnd_ofus_bad_magic;
    _afnd_ofus_bad_speed:
    {
        {
            if (!((_afnd_ofus_obscure(
                       _afnd_ofus_quux_ok(_afnd_ofus_gasp_google, j)) == INICIAL) ||
                  (_afnd_ofus_obscure(
                       _afnd_ofus_quux_ok(_afnd_ofus_gasp_google, j)) == INICIAL_Y_FINAL)))
                goto _afnd_ofus_bad_bill;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err,
                                       _afnd_ofus_bad_hello, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j + _afnd_ofus_gasp_trick));
            }
        _afnd_ofus_bad_bill:;
        }
        {
            if (!((_afnd_ofus_obscure(
                       _afnd_ofus_quux_ok(_afnd_ofus_gasp_google, j)) == FINAL) ||
                  (_afnd_ofus_obscure(
                       _afnd_ofus_quux_ok(_afnd_ofus_gasp_google, j)) == INICIAL_Y_FINAL)))
                goto _afnd_ofus_bad_joe;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err,
                                       AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j + _afnd_ofus_gasp_trick),
                                       _afnd_ofus_bad_bye);
            }
        _afnd_ofus_bad_joe:;
        }
    }
        goto _afnd_ofus_bad_index;
    _afnd_ofus_bad_obscure:;
    }
    return _afnd_ofus_gasp_err;
}
AFND *_afnd_ofus_bad_emacs(AFND *p_afnd)
{
    AFND *_afnd_ofus_bad_vi;
    char *_afnd_ofus_fobar_vi;
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * (strlen(p_afnd->nombre) + strlen("_10") + 1));
    strcpy(_afnd_ofus_fobar_vi, p_afnd->nombre);
    strcat(
        _afnd_ofus_fobar_vi, "_1O");
    _afnd_ofus_bad_vi = AFNDNuevo(_afnd_ofus_fobar_vi,
                                  p_afnd->num_estados + 1 + 1, p_afnd->num_simbolos);
    free(_afnd_ofus_fobar_vi);
    _afnd_ofus_bad_empty(_afnd_ofus_bad_vi, p_afnd);
    _afnd_ofus_gasp_nasa(
        _afnd_ofus_bad_vi, p_afnd, "", 0);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "_f_1O",
                      FINAL);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "_i_1O", INICIAL);
    _afnd_ofus_bad_ok(
        _afnd_ofus_bad_vi, p_afnd, "_i_1O", "_f_1O", 0);
    AFNDCierraLTransicion(
        _afnd_ofus_bad_vi);
    return _afnd_ofus_bad_vi;
}
AFND *_afnd_ofus_bad_rms(AFND *
                             _afnd_ofus_bad_fbi)
{
    AFND *_afnd_ofus_bad_vi;
    _afnd_ofus_bad_vi = AFNDNuevo(strcat(
                                      _afnd_ofus_bad_fbi->nombre, "'"),
                                  _afnd_ofus_bad_fbi->num_estados,
                                  _afnd_ofus_bad_fbi->num_simbolos);
    return _afnd_ofus_bad_vi;
}
_afnd_ofus_fast *
_afnd_ofus_quux_ok(AFND *p_afnd, int pos) { return p_afnd->_afnd_ofus_dog_obscure[pos]; }
_afnd_ofus_fast *_afnd_ofus_bad_cia(AFND *p_afnd, char *nombre)
{
    int pos;
    pos =
        AFNDIndiceDeEstado(p_afnd, nombre);
    return p_afnd->_afnd_ofus_dog_obscure[pos];
}
int AFNDTransicionIndicesEstadoiSimboloEstadof(AFND *p_afnd, int i_e1, int i_s,
                                               int i_e2) { return p_afnd->_afnd_ofus_dog_bill[i_e1][i_s][i_e2]; }
int AFNDCierreLTransicionIJ(AFND *p_afnd, int i, int j) { return _afnd_ofus_bar_empty(
    p_afnd->_afnd_ofus_dog_index, i, j); }
AFND *_afnd_ofus_bad_nasa(AFND *
                              _afnd_ofus_bad_err,
                          AFND *_afnd_ofus_bad_google)
{
    char *_afnd_ofus_fobar_vi;
    AFND *
        _afnd_ofus_bad_vi;
    _afnd_ofus_fbi *_afnd_ofus_bad_yahoo;
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * (strlen(_afnd_ofus_bad_err->nombre) + strlen("_1") +
                                                         strlen("_U_") + strlen(_afnd_ofus_bad_google->nombre) + strlen("_2") + 1));
    strcpy(
        _afnd_ofus_fobar_vi, _afnd_ofus_bad_err->nombre);
    strcat(_afnd_ofus_fobar_vi,
           "_1_U_");
    strcat(_afnd_ofus_fobar_vi, _afnd_ofus_bad_google->nombre);
    strcat(
        _afnd_ofus_fobar_vi, "_2");
    _afnd_ofus_bad_yahoo = _afnd_ofus_yellow(
        _afnd_ofus_bad_err->_afnd_ofus_dog_magic, _afnd_ofus_bad_google->_afnd_ofus_dog_magic);
    _afnd_ofus_bad_vi = AFNDNuevo(_afnd_ofus_fobar_vi,
                                  _afnd_ofus_bad_err->num_estados + 1 + 1 + _afnd_ofus_bad_google->num_estados,
                                  _afnd_ofus_green(_afnd_ofus_bad_yahoo));
    _afnd_ofus_err(_afnd_ofus_bad_vi->_afnd_ofus_dog_magic);
    _afnd_ofus_bad_vi->_afnd_ofus_dog_magic =
        _afnd_ofus_bad_yahoo;
    free(_afnd_ofus_fobar_vi);
    _afnd_ofus_bad_empty(
        _afnd_ofus_bad_vi, _afnd_ofus_bad_err);
    _afnd_ofus_gasp_nasa(_afnd_ofus_bad_vi,
                         _afnd_ofus_bad_err, "_U1_", 0);
    _afnd_ofus_gasp_nasa(_afnd_ofus_bad_vi,
                         _afnd_ofus_bad_google, "_U2_", _afnd_ofus_bad_err->num_estados);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "_i_1O", INICIAL);
    AFNDInsertaEstado(
        _afnd_ofus_bad_vi, "_f_1O", FINAL);
    _afnd_ofus_bad_ok(_afnd_ofus_bad_vi,
                      _afnd_ofus_bad_err, "_i_1O", "_f_1O", 0);
    _afnd_ofus_bad_ok(_afnd_ofus_bad_vi,
                      _afnd_ofus_bad_google, "_i_1O", "_f_1O", _afnd_ofus_bad_err->num_estados);
    AFNDCierraLTransicion(_afnd_ofus_bad_vi);
    return _afnd_ofus_bad_vi;
}
AFND *
_afnd_ofus_bad_trick(AFND *_afnd_ofus_bad_hint, AFND *_afnd_ofus_bad_black)
{
    AFND *
        _afnd_ofus_gasp_err;
    int i, j, _afnd_ofus_foobaz_cyan;
    _afnd_ofus_fast *
        _afnd_ofus_gasp_hint;
    int tipo;
    char *_afnd_ofus_fobar_vi;
    char *_afnd_ofus_bad_red = "_K1_";
    char *_afnd_ofus_bad_green = "_K2_";
    int _afnd_ofus_bad_yellow,
        _afnd_ofus_bad_blue;
    int _afnd_ofus_bad_magenta, _afnd_ofus_bad_cyan;
    char *
        _afnd_ofus_bad_hello = "_K_i";
    char *_afnd_ofus_bad_bye = "_K_f";
    _afnd_ofus_fbi *
        _afnd_ofus_bad_yahoo;
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * (strlen(
                                                             _afnd_ofus_bad_hint->nombre) +
                                                         strlen("_1") + strlen("_K_") + strlen(_afnd_ofus_bad_black->nombre) + strlen("_2") + 1));
    strcpy(_afnd_ofus_fobar_vi,
           _afnd_ofus_bad_hint->nombre);
    strcat(_afnd_ofus_fobar_vi, "_1_K_");
    strcat(
        _afnd_ofus_fobar_vi, _afnd_ofus_bad_black->nombre);
    strcat(_afnd_ofus_fobar_vi,
           "_2");
    _afnd_ofus_bad_yahoo = _afnd_ofus_yellow(_afnd_ofus_bad_hint->_afnd_ofus_dog_magic, _afnd_ofus_bad_black->_afnd_ofus_dog_magic);
    _afnd_ofus_gasp_err = AFNDNuevo(_afnd_ofus_fobar_vi, _afnd_ofus_bad_hint->num_estados + _afnd_ofus_bad_black->num_estados + 2, _afnd_ofus_green(_afnd_ofus_bad_yahoo));
    _afnd_ofus_err(_afnd_ofus_gasp_err->_afnd_ofus_dog_magic);
    _afnd_ofus_gasp_err->_afnd_ofus_dog_magic =
        _afnd_ofus_bad_yahoo;
    free(_afnd_ofus_fobar_vi);
    _afnd_ofus_bad_empty(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_hint);
    {
        i = 0;
    _afnd_ofus_bad_white:
        if (!(i <
              _afnd_ofus_bad_hint->num_estados))
            goto _afnd_ofus_bad_clinton;
        goto _afnd_ofus_bad_bush;
    _afnd_ofus_bad_jfk:
        i++;
        goto _afnd_ofus_bad_white;
    _afnd_ofus_bad_bush:
    {
        _afnd_ofus_gasp_hint = _afnd_ofus_quux_ok(
            _afnd_ofus_bad_hint, i);
        tipo = NORMAL;
        _afnd_ofus_fobar_vi = (char *)malloc(sizeof(
                                                 char) *
                                             (strlen(_afnd_ofus_bad_red) + strlen(_afnd_ofus_magic(_afnd_ofus_gasp_hint)) + 1));
        strcpy(_afnd_ofus_fobar_vi, _afnd_ofus_bad_red);
        strcat(
            _afnd_ofus_fobar_vi, _afnd_ofus_magic(_afnd_ofus_gasp_hint));
        AFNDInsertaEstado(
            _afnd_ofus_gasp_err, _afnd_ofus_fobar_vi, tipo);
        free(_afnd_ofus_fobar_vi);
    }
        goto _afnd_ofus_bad_jfk;
    _afnd_ofus_bad_clinton:;
    }
    {
        i = 0;
    _afnd_ofus_bad_sex:
        if (!(i <
              _afnd_ofus_bad_black->num_estados))
            goto _afnd_ofus_bug_foo;
        goto _afnd_ofus_bug_bar;
    _afnd_ofus_bug_baz:
        i++;
        goto _afnd_ofus_bad_sex;
    _afnd_ofus_bug_bar:
    {
        _afnd_ofus_gasp_hint = _afnd_ofus_quux_ok(
            _afnd_ofus_bad_black, i);
        tipo = NORMAL;
        _afnd_ofus_fobar_vi = (char *)malloc(sizeof(
                                                 char) *
                                             (strlen(_afnd_ofus_bad_green) + strlen(_afnd_ofus_magic(_afnd_ofus_gasp_hint)) + 1));
        strcpy(_afnd_ofus_fobar_vi, _afnd_ofus_bad_green);
        strcat(_afnd_ofus_fobar_vi, _afnd_ofus_magic(_afnd_ofus_gasp_hint));
        AFNDInsertaEstado(_afnd_ofus_gasp_err, _afnd_ofus_fobar_vi, tipo);
        free(
            _afnd_ofus_fobar_vi);
    }
        goto _afnd_ofus_bug_baz;
    _afnd_ofus_bug_foo:;
    }
    AFNDInsertaEstado(_afnd_ofus_gasp_err, _afnd_ofus_bad_hello, INICIAL);
    AFNDInsertaEstado(_afnd_ofus_gasp_err, _afnd_ofus_bad_bye, FINAL);
    {
        i = 0;
    _afnd_ofus_bug_fobar:
        if (!(i < _afnd_ofus_bad_hint->num_estados))
            goto _afnd_ofus_bug_foobar;
        goto _afnd_ofus_bug_fobaz;
    _afnd_ofus_bug_foobaz:
        i++;
        goto _afnd_ofus_bug_fobar;
    _afnd_ofus_bug_fobaz:
    {
        j = 0;
    _afnd_ofus_bug_quux:
        if (!(j <
              _afnd_ofus_bad_hint->num_simbolos))
            goto _afnd_ofus_bug_fred;
        goto _afnd_ofus_bug_dog;
    _afnd_ofus_bug_cat:
        j++;
        goto _afnd_ofus_bug_quux;
    _afnd_ofus_bug_dog:
    {
        _afnd_ofus_foobaz_cyan = 0;
    _afnd_ofus_bug_fish:
        if (!(
                _afnd_ofus_foobaz_cyan < _afnd_ofus_bad_hint->num_estados))
            goto _afnd_ofus_bug_gasp;
        goto _afnd_ofus_bug_bad;
    _afnd_ofus_bug_bug:
        _afnd_ofus_foobaz_cyan++;
        goto _afnd_ofus_bug_fish;
    _afnd_ofus_bug_bad:
    {
        {
            if (!(
                    AFNDTransicionIndicesEstadoiSimboloEstadof(_afnd_ofus_bad_hint, i, j,
                                                               _afnd_ofus_foobaz_cyan) == 1))
                goto _afnd_ofus_bug_silly;
            {
                AFNDInsertaTransicion(
                    _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i), AFNDSimboloEn(_afnd_ofus_gasp_err, j), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_foobaz_cyan));
            }
        _afnd_ofus_bug_silly:;
        }
    }
        goto _afnd_ofus_bug_bug;
    _afnd_ofus_bug_gasp:;
    }
        goto _afnd_ofus_bug_cat;
    _afnd_ofus_bug_fred:;
    }
        goto _afnd_ofus_bug_foobaz;
    _afnd_ofus_bug_foobar:;
    }
    {
        i = 0;
    _afnd_ofus_bug_buggy:
        if (!(i < _afnd_ofus_bad_black->num_estados))
            goto _afnd_ofus_bug_mum;
        goto _afnd_ofus_bug_dad;
    _afnd_ofus_bug_disk:
        i++;
        goto _afnd_ofus_bug_buggy;
    _afnd_ofus_bug_dad:
    {
        j = 0;
    _afnd_ofus_bug_empty:
        if (!(j < _afnd_ofus_bad_black->num_simbolos))
            goto _afnd_ofus_bug_full;
        goto _afnd_ofus_bug_fast;
    _afnd_ofus_bug_small:
        j++;
        goto _afnd_ofus_bug_empty;
    _afnd_ofus_bug_fast:
    {
        _afnd_ofus_foobaz_cyan = 0;
    _afnd_ofus_bug_big:
        if (!(_afnd_ofus_foobaz_cyan <
              _afnd_ofus_bad_black->num_estados))
            goto _afnd_ofus_bug_ok;
        goto _afnd_ofus_bug_hello;
    _afnd_ofus_bug_bye:
        _afnd_ofus_foobaz_cyan++;
        goto _afnd_ofus_bug_big;
    _afnd_ofus_bug_hello:
    {
        {
            if (!(
                    AFNDTransicionIndicesEstadoiSimboloEstadof(_afnd_ofus_bad_black, i, j,
                                                               _afnd_ofus_foobaz_cyan) == 1))
                goto _afnd_ofus_bug_magic;
            {
                AFNDInsertaTransicion(
                    _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i + _afnd_ofus_bad_hint->num_estados), AFNDSimboloEn(_afnd_ofus_bad_black, j),
                    AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_foobaz_cyan +
                                                                _afnd_ofus_bad_hint->num_estados));
            }
        _afnd_ofus_bug_magic:;
        }
    }
        goto _afnd_ofus_bug_bye;
    _afnd_ofus_bug_ok:;
    }
        goto _afnd_ofus_bug_small;
    _afnd_ofus_bug_full:;
    }
        goto _afnd_ofus_bug_disk;
    _afnd_ofus_bug_mum:;
    }
    {
        i = 0;
    _afnd_ofus_bug_obscure:
        if (!(i < _afnd_ofus_bad_hint->num_estados))
            goto _afnd_ofus_bug_speed;
        goto _afnd_ofus_bug_index;
    _afnd_ofus_bug_bill:
        i++;
        goto _afnd_ofus_bug_obscure;
    _afnd_ofus_bug_index:
    {
        j = 0;
    _afnd_ofus_bug_joe:
        if (!(j <
              _afnd_ofus_bad_hint->num_estados))
            goto _afnd_ofus_bug_emacs;
        goto _afnd_ofus_bug_vi;
    _afnd_ofus_bug_rms:
        j++;
        goto _afnd_ofus_bug_joe;
    _afnd_ofus_bug_vi:
    {
        {
            if (!(AFNDLTransicionIJ(_afnd_ofus_bad_hint, i, j) == 1))
                goto _afnd_ofus_bug_fbi;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err,
                                       AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j));
            }
        _afnd_ofus_bug_fbi:;
        }
    }
        goto _afnd_ofus_bug_rms;
    _afnd_ofus_bug_emacs:;
    }
        goto _afnd_ofus_bug_bill;
    _afnd_ofus_bug_speed:;
    }
    {
        i = 0;
    _afnd_ofus_bug_cia:
        if (!(i < _afnd_ofus_bad_black->num_estados))
            goto _afnd_ofus_bug_nasa;
        goto _afnd_ofus_bug_err;
    _afnd_ofus_bug_google:
        i++;
        goto _afnd_ofus_bug_cia;
    _afnd_ofus_bug_err:
    {
        j = 0;
    _afnd_ofus_bug_yahoo:
        if (!(j <
              _afnd_ofus_bad_black->num_estados))
            goto _afnd_ofus_bug_trick;
        goto _afnd_ofus_bug_hint;
    _afnd_ofus_bug_black:
        j++;
        goto _afnd_ofus_bug_yahoo;
    _afnd_ofus_bug_hint:
    {
        {
            if (!(AFNDLTransicionIJ(_afnd_ofus_bad_black, i, j) == 1))
                goto _afnd_ofus_bug_red;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err,
                                       AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i + _afnd_ofus_bad_hint->num_estados),
                                       AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j + _afnd_ofus_bad_hint->num_estados));
            }
        _afnd_ofus_bug_red:;
        }
    }
        goto _afnd_ofus_bug_black;
    _afnd_ofus_bug_trick:;
    }
        goto _afnd_ofus_bug_google;
    _afnd_ofus_bug_nasa:;
    }
    _afnd_ofus_bad_blue =
        AFNDIndiceEstadoInicial(_afnd_ofus_bad_black);
    _afnd_ofus_bad_cyan =
        AFNDIndiceEstadoInicial(_afnd_ofus_bad_hint);
    _afnd_ofus_bad_yellow =
        AFNDIndicePrimerEstadoFinal(_afnd_ofus_bad_hint);
    _afnd_ofus_bad_magenta =
        AFNDIndicePrimerEstadoFinal(_afnd_ofus_bad_black);
    AFNDInsertaLTransicion(
        _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bad_yellow), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bad_blue + _afnd_ofus_bad_hint->num_estados));
    AFNDInsertaLTransicion(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_hello, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bad_cyan));
    AFNDInsertaLTransicion(
        _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bad_hint->num_estados + _afnd_ofus_bad_magenta), _afnd_ofus_bad_bye);
    AFNDCierraLTransicion(_afnd_ofus_gasp_err);
    return _afnd_ofus_gasp_err;
}
AFND *
_afnd_ofus_bug_green(AFND *_afnd_ofus_gasp_google)
{
    char *_afnd_ofus_fobar_vi;
    AFND *_afnd_ofus_gasp_err;
    char *_afnd_ofus_gasp_yahoo = "X";
    int i, j,
        _afnd_ofus_foobaz_cyan;
    _afnd_ofus_fast *_afnd_ofus_gasp_hint;
    int tipo;
    int
        _afnd_ofus_bug_yellow,
        _afnd_ofus_bug_blue;
    char *_afnd_ofus_bad_hello = "_X_i";
    char *_afnd_ofus_bad_bye = "_X_f";
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) *
                                         (strlen(_afnd_ofus_gasp_google->nombre) + strlen("X") + 1));
    strcpy(
        _afnd_ofus_fobar_vi, _afnd_ofus_gasp_google->nombre);
    strcat(_afnd_ofus_fobar_vi, "X");
    _afnd_ofus_gasp_err = AFNDNuevo(_afnd_ofus_fobar_vi, _afnd_ofus_gasp_google->num_estados + 2, _afnd_ofus_gasp_google->num_simbolos);
    free(_afnd_ofus_fobar_vi);
    _afnd_ofus_bad_empty(_afnd_ofus_gasp_err, _afnd_ofus_gasp_google);
    {
        i = 0;
    _afnd_ofus_bug_magenta:
        if (!(i < _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bug_cyan;
        goto _afnd_ofus_bug_white;
    _afnd_ofus_bug_clinton:
        i++;
        goto _afnd_ofus_bug_magenta;
    _afnd_ofus_bug_white:
    {
        _afnd_ofus_gasp_hint =
            _afnd_ofus_quux_ok(_afnd_ofus_gasp_google, i);
        tipo = NORMAL;
        _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * (strlen(_afnd_ofus_gasp_yahoo) + strlen(_afnd_ofus_magic(_afnd_ofus_gasp_hint)) + 1));
        strcpy(_afnd_ofus_fobar_vi,
               _afnd_ofus_gasp_yahoo);
        strcat(_afnd_ofus_fobar_vi, _afnd_ofus_magic(
                                        _afnd_ofus_gasp_hint));
        AFNDInsertaEstado(_afnd_ofus_gasp_err,
                          _afnd_ofus_fobar_vi, tipo);
        free(_afnd_ofus_fobar_vi);
    }
        goto _afnd_ofus_bug_clinton;
    _afnd_ofus_bug_cyan:;
    }
    AFNDInsertaEstado(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_hello, INICIAL);
    AFNDInsertaEstado(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_bye, FINAL);
    {
        i = 0;
    _afnd_ofus_bug_bush:
        if (!(i <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_bug_jfk;
        goto _afnd_ofus_bug_sex;
    _afnd_ofus_silly_foo:
        i++;
        goto _afnd_ofus_bug_bush;
    _afnd_ofus_bug_sex:
    {
        j = 0;
    _afnd_ofus_silly_bar:
        if (!(j < _afnd_ofus_gasp_google->num_simbolos))
            goto _afnd_ofus_silly_baz;
        goto _afnd_ofus_silly_fobar;
    _afnd_ofus_silly_foobar:
        j++;
        goto _afnd_ofus_silly_bar;
    _afnd_ofus_silly_fobar:
    {
        _afnd_ofus_foobaz_cyan = 0;
    _afnd_ofus_silly_fobaz:
        if (!(_afnd_ofus_foobaz_cyan <
              _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_silly_foobaz;
        goto _afnd_ofus_silly_quux;
    _afnd_ofus_silly_fred:
        _afnd_ofus_foobaz_cyan++;
        goto _afnd_ofus_silly_fobaz;
    _afnd_ofus_silly_quux:
    {
        {
            if (!(
                    AFNDTransicionIndicesEstadoiSimboloEstadof(_afnd_ofus_gasp_google, i, j,
                                                               _afnd_ofus_foobaz_cyan) == 1))
                goto _afnd_ofus_silly_dog;
            {
                AFNDInsertaTransicion(
                    _afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i), AFNDSimboloEn(_afnd_ofus_gasp_err, j), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_foobaz_cyan));
            }
        _afnd_ofus_silly_dog:;
        }
    }
        goto _afnd_ofus_silly_fred;
    _afnd_ofus_silly_foobaz:;
    }
        goto _afnd_ofus_silly_foobar;
    _afnd_ofus_silly_baz:;
    }
        goto _afnd_ofus_silly_foo;
    _afnd_ofus_bug_jfk:;
    }
    {
        i = 0;
    _afnd_ofus_silly_cat:
        if (!(
                i < _afnd_ofus_gasp_google->num_estados))
            goto _afnd_ofus_silly_fish;
        goto _afnd_ofus_silly_gasp;
    _afnd_ofus_silly_bad:
        i++;
        goto _afnd_ofus_silly_cat;
    _afnd_ofus_silly_gasp:
    {
        j = 0;
    _afnd_ofus_silly_bug:
        if (!(j < _afnd_ofus_gasp_google
                      ->num_estados))
            goto _afnd_ofus_silly_silly;
        goto _afnd_ofus_silly_buggy;
    _afnd_ofus_silly_mum:
        j++;
        goto _afnd_ofus_silly_bug;
    _afnd_ofus_silly_buggy:
    {
        {
            if (!(AFNDLTransicionIJ(_afnd_ofus_gasp_google, i, j) == 1))
                goto _afnd_ofus_silly_dad;
            {
                AFNDInsertaLTransicion(_afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, i), AFNDNombreEstadoEn(_afnd_ofus_gasp_err, j));
            }
        _afnd_ofus_silly_dad:;
        }
    }
        goto _afnd_ofus_silly_mum;
    _afnd_ofus_silly_silly:;
    }
        goto _afnd_ofus_silly_bad;
    _afnd_ofus_silly_fish:;
    }
    _afnd_ofus_bug_yellow =
        AFNDIndiceEstadoInicial(_afnd_ofus_gasp_google);
    _afnd_ofus_bug_blue =
        AFNDIndicePrimerEstadoFinal(_afnd_ofus_gasp_google);
    AFNDInsertaLTransicion(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_hello, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bug_yellow));
    AFNDInsertaLTransicion(
        _afnd_ofus_gasp_err, _afnd_ofus_bad_hello, _afnd_ofus_bad_bye);
    AFNDInsertaLTransicion(_afnd_ofus_gasp_err, AFNDNombreEstadoEn(_afnd_ofus_gasp_err, _afnd_ofus_bug_blue), _afnd_ofus_bad_bye);
    AFNDInsertaLTransicion(_afnd_ofus_gasp_err, _afnd_ofus_bad_bye,
                           _afnd_ofus_bad_hello);
    AFNDCierraLTransicion(_afnd_ofus_gasp_err);
    return _afnd_ofus_gasp_err;
}
AFND *_afnd_ofus_silly_disk(char *simbolo)
{
    AFND *
        _afnd_ofus_bad_vi;
    char *_afnd_ofus_fobar_vi;
    _afnd_ofus_fobar_vi = (char *)malloc(
        sizeof(char) * strlen("afnd1o_") + strlen(simbolo) + 1);
    strcpy(_afnd_ofus_fobar_vi,
           "anfd1o_");
    strcat(_afnd_ofus_fobar_vi, simbolo);
    _afnd_ofus_bad_vi = AFNDNuevo(
        _afnd_ofus_fobar_vi, 2, 1);
    free(_afnd_ofus_fobar_vi);
    AFNDInsertaSimbolo(
        _afnd_ofus_bad_vi, simbolo);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "q0", INICIAL);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "qf", FINAL);
    AFNDInsertaTransicion(
        _afnd_ofus_bad_vi, "q0", simbolo, "qf");
    return _afnd_ofus_bad_vi;
}
AFND *
_afnd_ofus_silly_empty()
{
    AFND *_afnd_ofus_bad_vi;
    char *_afnd_ofus_fobar_vi;
    _afnd_ofus_fobar_vi = (char *)malloc(sizeof(char) * strlen("l") + 1);
    strcpy(
        _afnd_ofus_fobar_vi, "lambda");
    _afnd_ofus_bad_vi = AFNDNuevo(_afnd_ofus_fobar_vi,
                                  1, 0);
    free(_afnd_ofus_fobar_vi);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "q0",
                      INICIAL_Y_FINAL);
    return _afnd_ofus_bad_vi;
}
AFND *_afnd_ofus_silly_full()
{
    AFND *
        _afnd_ofus_bad_vi;
    char *_afnd_ofus_fobar_vi;
    _afnd_ofus_fobar_vi = (char *)malloc(
        sizeof(char) * strlen("0") + 1);
    strcpy(_afnd_ofus_fobar_vi, "empty");
    _afnd_ofus_bad_vi = AFNDNuevo(_afnd_ofus_fobar_vi, 2, 0);
    free(_afnd_ofus_fobar_vi);
    AFNDInsertaEstado(_afnd_ofus_bad_vi, "q0", INICIAL);
    AFNDInsertaEstado(
        _afnd_ofus_bad_vi, "qf", FINAL);
    return _afnd_ofus_bad_vi;
}
void AFNDADot(AFND *
                  p_afnd)
{
    int i, j, _afnd_ofus_foobaz_cyan;
    FILE *_afnd_ofus_silly_fast;
    char *
        _afnd_ofus_silly_small;
    fprintf(stdout, "ENTRA");
    _afnd_ofus_silly_small = (char *)
        malloc(sizeof(char) * (strlen(p_afnd->nombre) + 1 + strlen(".dot")));
    strcpy(
        _afnd_ofus_silly_small, p_afnd->nombre);
    strcat(_afnd_ofus_silly_small, ".dot");
    _afnd_ofus_silly_fast = fopen(_afnd_ofus_silly_small, "w");
    free(
        _afnd_ofus_silly_small);
    printf("CREA Nombre fichero");
    fprintf(
        _afnd_ofus_silly_fast, "digraph %s  { rankdir=LR;\n", p_afnd->nombre);
    fprintf(
        _afnd_ofus_silly_fast, "\t_invisible [style=\"invis\"];\n");
    {
        i = 0;
    _afnd_ofus_silly_big:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_silly_ok;
        goto _afnd_ofus_silly_hello;
    _afnd_ofus_silly_bye:
        i++;
        goto _afnd_ofus_silly_big;
    _afnd_ofus_silly_hello:
    {
        printf("ESTADO A DOT");
        _afnd_ofus_emacs(
            _afnd_ofus_silly_fast, p_afnd->_afnd_ofus_dog_obscure[i]);
    }
        goto _afnd_ofus_silly_bye;
    _afnd_ofus_silly_ok:;
    }
    fprintf(_afnd_ofus_silly_fast,
            "\t_invisible -> %s ;\n", AFNDNombreEstadoEn(p_afnd, AFNDIndiceEstadoInicial(p_afnd)));
    {
        i = 0;
    _afnd_ofus_silly_magic:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_silly_obscure;
        goto _afnd_ofus_silly_speed;
    _afnd_ofus_silly_index:
        i++;
        goto _afnd_ofus_silly_magic;
    _afnd_ofus_silly_speed:
    {
        j = 0;
    _afnd_ofus_silly_bill:
        if (!(j < p_afnd->num_simbolos))
            goto _afnd_ofus_silly_joe;
        goto _afnd_ofus_silly_emacs;
    _afnd_ofus_silly_vi:
        j++;
        goto _afnd_ofus_silly_bill;
    _afnd_ofus_silly_emacs:
    {
        _afnd_ofus_foobaz_cyan = 0;
    _afnd_ofus_silly_rms:
        if (!(
                _afnd_ofus_foobaz_cyan < p_afnd->num_estados))
            goto _afnd_ofus_silly_fbi;
        goto _afnd_ofus_silly_cia;
    _afnd_ofus_silly_nasa:
        _afnd_ofus_foobaz_cyan++;
        goto _afnd_ofus_silly_rms;
    _afnd_ofus_silly_cia:
    {
        {
            if (!(1 ==
                  AFNDTransicionIndicesEstadoiSimboloEstadof(p_afnd, i, j, _afnd_ofus_foobaz_cyan)))
                goto _afnd_ofus_silly_err;
            fprintf(_afnd_ofus_silly_fast,
                    "\t%s -> %s [label=\"%s\"];\n", AFNDNombreEstadoEn(p_afnd, i), AFNDNombreEstadoEn(p_afnd, _afnd_ofus_foobaz_cyan), AFNDSimboloEn(p_afnd, j));
        _afnd_ofus_silly_err:;
        }
    }
        goto _afnd_ofus_silly_nasa;
    _afnd_ofus_silly_fbi:;
    }
        goto _afnd_ofus_silly_vi;
    _afnd_ofus_silly_joe:;
    }
        goto _afnd_ofus_silly_index;
    _afnd_ofus_silly_obscure:;
    }
    {
        i = 0;
    _afnd_ofus_silly_google:
        if (!(i < p_afnd->num_estados))
            goto _afnd_ofus_silly_yahoo;
        goto _afnd_ofus_silly_trick;
    _afnd_ofus_silly_hint:
        i++;
        goto _afnd_ofus_silly_google;
    _afnd_ofus_silly_trick:
    {
        j = 0;
    _afnd_ofus_silly_black:
        if (!(j < p_afnd->num_estados))
            goto _afnd_ofus_silly_red;
        goto _afnd_ofus_silly_green;
    _afnd_ofus_silly_yellow:
        j++;
        goto _afnd_ofus_silly_black;
    _afnd_ofus_silly_green:
    {
        {
            if (!(AFNDLTransicionIJ(p_afnd,
                                    i, j) == 1))
                goto _afnd_ofus_silly_blue;
            fprintf(_afnd_ofus_silly_fast,
                    "\t%s -> %s [label=\"&lambda;\"];\n", AFNDNombreEstadoEn(p_afnd, i),
                    AFNDNombreEstadoEn(p_afnd, j));
        _afnd_ofus_silly_blue:;
        }
    }
        goto _afnd_ofus_silly_yellow;
    _afnd_ofus_silly_red:;
    }
        goto _afnd_ofus_silly_hint;
    _afnd_ofus_silly_yahoo:;
    }
    fprintf(_afnd_ofus_silly_fast, "}");
    fclose(
        _afnd_ofus_silly_fast);
    return;
}
int AFNDNumSimbolos(AFND *p_afnd) { return p_afnd
                                        ->num_simbolos; }
int AFNDNumEstados(AFND *p_afnd) { return p_afnd->num_estados; }
int AFNDTipoEstadoEn(AFND *p_afnd, int pos) { return _afnd_ofus_obscure(p_afnd->_afnd_ofus_dog_obscure[pos]); }
